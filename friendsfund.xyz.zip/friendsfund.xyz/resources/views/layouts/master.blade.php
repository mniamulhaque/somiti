<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Friends Fund Family</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Favicon -->
    <link href="{{asset('backend_assets/LandingPage/img/favicon.ico')}}" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&family=Poppins:wght@600;700&display=swap"
      rel="stylesheet"
    />

    <!-- Icon Font Stylesheet -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
      rel="stylesheet"
    />

    <!-- Libraries Stylesheet -->
    <link href="{{asset('backend_assets/LandingPage/lib/animate/animate.min.css')}}" rel="stylesheet" />
    <link href="{{asset('backend_assets/LandingPage/lib/owlcarousel/assets/owl.carousel.min.css')}}" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="{{asset('backend_assets/LandingPage/css/bootstrap.min.css')}}" rel="stylesheet" />

    <!-- Template Stylesheet -->
    <link href="{{asset('backend_assets/LandingPage/css/style.css')}}" rel="stylesheet" />
  </head>

  <body>
    <!-- Spinner Start -->
    <div
      id="spinner"
      class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center"
    >
      <div class="spinner-grow text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->

    <!-- Topbar Start -->
    
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <nav
      class="navbar navbar-expand-lg bg-white navbar-light sticky-top px-4 px-lg-5"
    >
      <a href="{{url('/home')}}" class="navbar-brand d-flex align-items-center">
        <h2 class="m-0">
          <img
            class="img-fluid me-3"
            src="{{asset('backend_assets/LandingPage/img/icon/fffLogopng.png')}}"
            alt=""
          />Friends Fund
        </h2>
      </a>
      <button
        type="button"
        class="navbar-toggler"
        data-bs-toggle="collapse"
        data-bs-target="#navbarCollapse"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav mx-auto bg-light rounded pe-4 py-3 py-lg-0">
          <a href="{{url('/home')}}" class="nav-item nav-link active">Home</a>
          <a href="#" class="nav-item nav-link">About Us</a>
          <a href="#" class="nav-item nav-link">Our Services</a>
          <a href="{{url('/ourmember')}}" class="nav-item nav-link">Our Members</a>
          <a href="#" class="nav-item nav-link">Contact Us</a>
          <a href="{{url('/member_login')}}" class="nav-item nav-link">Login</a>
        </div>
      </div>
  	<a href="#" class="btn btn-primary px-3 d-none d-lg-block">Join Us</a>
    </nav>
    <!-- Navbar End -->
     @yield('body')
    <!-- Footer Start -->
    <div
      class="container-fluid bg-dark footer mt-5 pt-5 wow fadeIn"
      data-wow-delay="0.1s"
    >
      <div class="container py-5">
        <div class="row g-5">
          <div class="col-lg-3 col-md-6">
            <h4 class="text-white mb-2">
              <img
                class="img-fluid me-1" style="height: 80px;width: 80px;"
                src="{{asset('backend_assets/LandingPage/img/icon/fffLogopng.png')}}"
                alt=""
              />Friends Fund
            </h4>
            <p>
              সঞ্চয় ছাড়া জীবনে উন্নতি লাভ সম্ভব নয়। আমাদের জীবনে সফলতা লাভ করতে হলে প্রত্যেকের উচিত জীবনে কঠোর পরিশ্রম করে সঞ্চয় করা। তাহলে আমাদের ভবিষ্যৎ জীবন সুন্দর হয়ে উঠবে।
            </p>
            <div class="d-flex pt-2">
              <a class="btn btn-square me-1" href=""
                ><i class="fab fa-twitter"></i
              ></a>
              <a class="btn btn-square me-1" href=""
                ><i class="fab fa-facebook-f"></i
              ></a>
              <a class="btn btn-square me-1" href=""
                ><i class="fab fa-youtube"></i
              ></a>
              <a class="btn btn-square me-0" href=""
                ><i class="fab fa-linkedin-in"></i
              ></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <h5 class="text-light mb-4">Address</h5>
            <p>
              <i class="fa fa-map-marker-alt me-3"></i>Daudkandi, Cumilla
            </p>
            <p><i class="fa fa-phone-alt me-3"></i>+880 1837180701</p>
            <p><i class="fa fa-envelope me-3"></i>info@friendsfund.com</p>
          </div>
          <div class="col-lg-3 col-md-6">
            <h5 class="text-light mb-4">Quick Links</h5>
            <a class="btn btn-link" href="">About Us</a>
            <a class="btn btn-link" href="">Contact Us</a>
            <a class="btn btn-link" href="">Our Services</a>
            <a class="btn btn-link" href="">Terms & Condition</a>
            <a class="btn btn-link" href="">Support</a>
          </div>
          <div class="col-lg-3 col-md-6">
            <h5 class="text-light mb-4">Newsletter</h5>
            <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
            <div class="position-relative mx-auto" style="max-width: 400px">
              <input
                class="form-control bg-transparent w-100 py-3 ps-4 pe-5"
                type="text"
                placeholder="Your email"
              />
              <button
                type="button"
                class="btn btn-secondary py-2 position-absolute top-0 end-0 mt-2 me-2"
              >
                SignUp
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="container-fluid copyright">
        <div class="container">
          <div class="row">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
              &copy; <a href="#">Friends Fund Family</a>, All Right Reserved.
            </div>
            <div class="col-md-6 text-center text-md-end">
              <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
              Designed By <a href="https:niamul.com">Niamul Haque</a>
              <br />Distributed By:
              <a href="https://nhsoftware.com" target="_blank">NH Software</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"
      ><i class="bi bi-arrow-up"></i
    ></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{asset('backend_assets/LandingPage/lib/wow/wow.min.js')}}"></script>
    <script src="{{asset('backend_assets/LandingPage/lib/easing/easing.min.js')}}"></script>
    <script src="{{asset('backend_assets/LandingPage/lib/waypoints/waypoints.min.js')}}"></script>
    <script src="{{asset('backend_assets/LandingPage/lib/owlcarousel/owl.carousel.min.js')}}"></script>
    <script src="{{asset('backend_assets/LandingPage/lib/counterup/counterup.min.js')}}"></script>

    <!-- Template Javascript -->
    <script src="{{asset('backend_assets/LandingPage/js/main.js')}}"></script>
  </body>
</html>
