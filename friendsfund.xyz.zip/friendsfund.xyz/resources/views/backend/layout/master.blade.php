<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    
    <!-- theme meta -->
    <meta name="theme-name" content="quixlab" />
  
    <title>Friends Fund Family</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{asset('backend_assets/images/favicon.png')}}">
    <!-- Pignose Calender -->
    <link href="{{asset('backend_assets/plugins/pg-calendar/css/pignose.calendar.min.css')}}" rel="stylesheet">
    <!-- Chartist -->
    <link rel="stylesheet" href="{{asset('backend_assets/plugins/chartist/css/chartist.min.css')}}">
    <link href="{{asset('backend_assets/plugins/tables/css/datatable/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('backend_assets/plugins/chartist-plugin-tooltips/css/chartist-plugin-tooltip.css')}}">
    <!-- Custom Stylesheet -->
    <link href="{{asset('backend_assets/css/style.css')}}" rel="stylesheet">
    <link href="{{asset('backend_assets/css/niamulstyle.css')}}" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header" style="background: #fff;">
            <div class="brand-logo">
                <a href="{{url('/home')}}">
                    <b class="logo-abbr"><img src="{{asset('backend_assets/images/logo.png')}}" alt=""> </b>
                    <span class="logo-compact"><img src="{{asset('backend_assets/images/logo-compact.png')}}" alt="" height="60" width="150"></span>
                    <span class="brand-title">
                        <img src="{{asset('backend_assets/images/logo-compact.png')}}" alt="" height="60" width="147">
                    </span>
                </a>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <div class="header">    
            <div class="header-content clearfix">
                
                <div class="nav-control">
                    <div class="hamburger">
                        <span class="toggle-icon"><i class="icon-menu"></i></span>
                    </div>
                </div>
                <div class="header-left">
                    <div class="input-group icons">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-transparent border-0 pr-2 pr-sm-3" id="basic-addon1"><i class="mdi mdi-magnify"></i></span>
                        </div>
                        <input type="search" class="form-control" placeholder="Search Dashboard" aria-label="Search Dashboard">
                        <div class="drop-down animated flipInX d-md-none">
                            <form action="#">
                                <input type="text" class="form-control" placeholder="Search">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="header-right">
                    <ul class="clearfix">
                        <li class="icons dropdown"><a href="javascript:void(0)" data-toggle="dropdown">
                                <i class="mdi mdi-email-outline"></i>
                                <span class="badge badge-pill gradient-1">3</span>
                            </a>
                            <div class="drop-down animated fadeIn dropdown-menu">
                                <div class="dropdown-content-heading d-flex justify-content-between">
                                    <span class="">3 New Messages</span>  
                                    <a href="javascript:void()" class="d-inline-block">
                                        <span class="badge badge-pill gradient-1">3</span>
                                    </a>
                                </div>
                                <div class="dropdown-content-body">
                                    <ul>
                                        <li class="notification-unread">
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/1.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Saiful Islam</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Hi Teddy, Just wanted to let you ...</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="notification-unread">
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/2.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Adam Smith</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Can you do me a favour?</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/3.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Barak Obama</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Hi Teddy, Just wanted to let you ...</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/4.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Hilari Clinton</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Hello</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </li>
                        <li class="icons dropdown"><a href="javascript:void(0)" data-toggle="dropdown">
                                <i class="mdi mdi-bell-outline"></i>
                                <span class="badge badge-pill gradient-2">3</span>
                            </a>
                            <div class="drop-down animated fadeIn dropdown-menu dropdown-notfication">
                                <div class="dropdown-content-heading d-flex justify-content-between">
                                    <span class="">2 New Notifications</span>  
                                    <a href="javascript:void()" class="d-inline-block">
                                        <span class="badge badge-pill gradient-2">5</span>
                                    </a>
                                </div>
                                <div class="dropdown-content-body">
                                    <ul>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-success-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Events near you</h6>
                                                    <span class="notification-text">Within next 5 days</span> 
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-danger-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Event Started</h6>
                                                    <span class="notification-text">One hour ago</span> 
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-success-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Event Ended Successfully</h6>
                                                    <span class="notification-text">One hour ago</span>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-danger-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Events to Join</h6>
                                                    <span class="notification-text">After two days</span> 
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </li>
                        <li class="icons dropdown d-none d-md-flex">
                            <a href="javascript:void(0)" class="log-user"  data-toggle="dropdown">
                                <span>English</span>  <i class="fa fa-angle-down f-s-14" aria-hidden="true"></i>
                            </a>
                            <div class="drop-down dropdown-language animated fadeIn  dropdown-menu">
                                <div class="dropdown-content-body">
                                    <ul>
                                        <li><a href="javascript:void()">English</a></li>
                                        <li><a href="javascript:void()">Dutch</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li class="icons dropdown">
                            <div class="user-img c-pointer position-relative"   data-toggle="dropdown">
                                <span class="activity active"></span>
                                <img src="{{asset('backend_assets/images/user/1.png')}}" height="40" width="40" alt="">
                            </div>
                            <div class="drop-down dropdown-profile animated fadeIn dropdown-menu">
                                <div class="dropdown-content-body">
                                    <ul>
                                        <li>
                                            <a href="app-profile.html"><i class="icon-user"></i> <span>Profile</span></a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <i class="icon-envelope-open"></i> <span>Inbox</span> <div class="badge gradient-3 badge-pill gradient-1">3</div>
                                            </a>
                                        </li>
                                        <hr class="my-2">
                                        <li>
                                            <a href="page-lock.html"><i class="icon-settings"></i> <span>Settings</span></a>
                                        </li>
                                        <li>
                                            <a href="page-lock.html"><i class="icon-lock"></i> <span>Lock Screen</span></a>
                                        </li>
                                        <li>
                                            
                                            <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="nk-sidebar">           
            <div class="nk-nav-scroll">
                <ul class="metismenu" id="menu">
                    <li>
                        <a href="{{url('/home')}}" aria-expanded="false">
                            <i class="icon-badge menu-icon"></i><span class="nav-text">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{url('/addMember')}}"><i class="icon-badge menu-icon"></i><span class="nav-text">Add New Member</span></a>
                    </li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon-globe-alt menu-icon"></i><span class="nav-text">Member</span>
                        </a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/memberList')}}">Total Member</a></li>
                            <li><a href="{{url('/buyerMemberList')}}" aria-expanded="false">Share Buyer Member</a></li>
                        </ul>
                    </li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon-globe-alt menu-icon"></i><span class="nav-text">Share</span>
                        </a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addShare')}}">Add Share</a></li>
                            <li><a href="{{url('/shareList')}}" aria-expanded="false">Share List</a></li>
                            <li><a href="{{url('/buyshare')}}" aria-expanded="false">Buy Share</a></li>
                            <li><a href="{{url('/buyerList')}}" aria-expanded="false">buyer List</a></li>
                        </ul>
                    </li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon-globe-alt menu-icon"></i><span class="nav-text">Invest</span>
                        </a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addInvest')}}">Add Invest</a></li>
                            <li><a href="{{url('/investList')}}" aria-expanded="false">Invest List</a></li>
                        </ul>
                    </li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon-globe-alt menu-icon"></i><span class="nav-text">Invest Profit</span>
                        </a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addInvestProfit')}}">Add Profit</a></li>
                            <li><a href="{{url('/profitInvestList')}}" aria-expanded="false">Profit List</a></li>
                        </ul>
                    </li>

                    <li class="mega-menu mega-menu-sm">
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon-globe-alt menu-icon"></i><span class="nav-text">Month Deposit</span>
                        </a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/CrMonthDepositList')}}">month Deposit List</a></li>
                            <li><a href="{{url('/addmonthDeposit')}}">Add month Deposit</a></li>
                            <li><a href="{{url('/searchMemberdeposit')}}" aria-expanded="false">Check Member Deposit List</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
        @yield('body')

         <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="https://themeforest.net/user/quixlab">Quixlab</a> 2018</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="{{asset('backend_assets/plugins/common/common.min.js')}}"></script>
    <script src="{{asset('backend_assets/js/custom.min.js')}}"></script>
    <script src="{{asset('backend_assets/js/settings.js')}}"></script>
    <script src="{{asset('backend_assets/js/gleek.js')}}"></script>
    <script src="{{asset('backend_assets/js/styleSwitcher.js')}}"></script>

    <!-- Table Database -->
    <script src="{{asset('backend_assets/plugins/tables/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('backend_assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js')}}"></script>
    <script src="{{asset('backend_assets/plugins/tables/js/datatable-init/datatable-basic.min.js')}}"></script>
    <!-- Chartjs -->
    <script src="{{asset('backend_assets/plugins/chart.js/Chart.bundle.min.js')}}"></script>
    <!-- Circle progress -->
    <script src="{{asset('backend_assets/plugins/circle-progress/circle-progress.min.js')}}"></script>
    <!-- Datamap -->
    <script src="{{asset('backend_assets/plugins/d3v3/index.js')}}"></script>
    <script src="{{asset('backend_assets/plugins/topojson/topojson.min.js')}}"></script>
    <script src="{{asset('backend_assets/plugins/datamaps/datamaps.world.min.js')}}"></script>
    <!-- Morrisjs -->
    <script src="{{asset('backend_assets/plugins/raphael/raphael.min.js')}}"></script>
    <script src="{{asset('backend_assets/plugins/morris/morris.min.js')}}"></script>
    <!-- Pignose Calender -->
    <script src="{{asset('backend_assets/plugins/moment/moment.min.js')}}"></script>
    <script src="{{asset('backend_assets/plugins/pg-calendar/js/pignose.calendar.min.js')}}"></script>
    <!-- ChartistJS -->
    <script src="{{asset('backend_assets/plugins/chartist/js/chartist.min.js')}}"></script>
    <script src="{{asset('backend_assets/plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js')}}"></script>



    <script src="{{asset('backend_assets/js/dashboard/dashboard-1.js')}}"></script>

    <script type="text/javascript">
        
        //addInvestProfit
       $(document).ready(function(){
       $('#invest_id').on('change',function(){
                    let invest_id = $(this).val();
                    if(invest_id){
                    $('#share_id').empty();
                    $('#share_id').append(`<option value="0" disabled selected>Processing...</option>`);
                    $('#lonaner_name').empty();
                    $('#lonaner_name').append(`<option value="0" disabled selected>Processing...</option>`);

                    $('#invest_amount').empty();
                    $('#invest_amount').append(`Processing...`);

                    $('#lonan_expair_date').empty();
                    $('#lonan_expair_date').append(`Processing...`);

                    $('#profit_system').empty();
                    $('#profit_system').append(`<option value="0" disabled selected>Processing...</option>`);

                    $('#profit_previous_due').empty();
                    $('#profit_previous_due').append(`Processing...`);

                    $('#Total_profit_paid_qiantity').empty();
                    $('#Total_profit_paid_qiantity').append(`Processing...`);

                    $('#fixt_profit_amount').empty();
                    $('#fixt_profit_amount').append(`Processing...`);

                    $.ajax({
                      type: 'GET',
                      url: 'investSelect/'+ invest_id,
                      success: function (response) {
                      var response = JSON.parse(response);
                      console.log(response);   
                      $('#share_id').empty();
                      $('#share_name').empty();
                      $('#invest_name').empty();
                      $('#lonaner_name').empty();
                      $('#invest_amount').empty();
                      $('#lonan_expair_date').empty();
                      $('#profit_system').empty();
                      $('#profit_previous_due').empty();
                      $('#Total_profit_paid_qiantity').empty();
                      $('#fixt_profit_amount').empty();
                      
                      $('#invest_name').val(`${response.invest_name}`);
                      $('#share_name').val(`${response.share_name}`);
                      $('#share_id').append(`<option value="${response.share_id}">${response.share_name}</option>`);
                      $('#lonaner_name').append(`<option value="${response.lonaner_name}">${response.lonaner_name}</option>`);

                      $('#invest_amount').val(`${response.invest_amount}`);
                      $('#lonan_expair_date').val(`${response.lonan_expair_date}`);

                      $('#profit_system').append(`<option value="${response.profit_system}">${response.profit_system}</option>`);

                      $('#profit_previous_due').val(`${response.profit_previous_due}`);
                      $('#Total_profit_paid_qiantity').val(`${response.Total_profit_paid_qiantity}`);
                      $('#fixt_profit_amount').val(`${response.fixt_profit_amount}`);
                      }
                  });
                }else{
                    $('#share_id').val('');
                    $('#invest_name').val('');
                    $('#lonaner_name').empty();
                    $('#lonaner_name').append(`<option value="">Select at first Invest Name</option>`);

                    $('#invest_amount').val('');

                    $('#lonan_expair_date').val('');

                    $('#profit_system').empty();
                    $('#profit_system').append(`<option value="0" disabled selected>Select at first Invest Name</option>`);

                    $('#profit_previous_due').val('');
                    

                    $('#Total_profit_paid_qiantity').val('');
                    

                    $('#fixt_profit_amount').val('');
                }
                });
          });

       //addMonthDeposit
       $(document).ready(function(){
       $('#addmonthshare_id').on('change',function(){
                    let addmonthshare_id = $(this).val();
                    if(addmonthshare_id){
                    $('#invoice_date').empty();
                    $('#invoice_date').append(`<option value="0" disabled selected>Processing...</option>`);
                   

                    $.ajax({
                      type: 'GET',
                      url: 'addmonthSelect/'+ addmonthshare_id,
                      success: function (response) {
                      var response = JSON.parse(response);
                      console.log(response);
                      $('#invoice_date').empty();
                      $('#invoice_date').append(
                      `<option value="">Select Month</option>`
                          );
                      $.each(response , function(index, item) { 
                       $('#invoice_date').append(
                      `<option value="${item.bill_id}">${item.invoice_date}</option>`
                          );
                       });
                      }
                  });
                }else{
                    $('#invoice_date').val('');
                }
                });
          });
    </script>

</body>

</html>
