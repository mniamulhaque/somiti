@extends('backend.layout.master')
  @section('body')
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Invest</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Add New Invest</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">New Invest Form</h4>
                                <h4 class="card-title">
                                   @if($errors->has('invest_name'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('invest_name')}}
                                        </div>
                                    @elseif($errors->has('lonaner_name'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('lonaner_name')}}
                                        </div>
                                    @elseif($errors->has('invest_amount'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('invest_amount')}}
                                        </div>
                                    @elseif($errors->has('lonan_expair_date'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('lonan_expair_date')}}
                                        </div>
                                    @elseif($errors->has('profit_system'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('profit_system')}}
                                        </div>
                                    @elseif($errors->has('Profit_amount'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('Profit_amount')}}
                                        </div>
                                    @elseif(Session::has('message'))
                                        <div class="alert alert-success" role="alert">
                                          {{Session::get('message')}}
                                        </div>
                                    @endif
                                 </h4>
                                <div class="basic-form">
                                    <form class="forms-sample" action="{{url('/addInvest')}}" method="POST">
                                        @csrf
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label>Invest Name</label>
                                                <input type="text" name="invest_name" class="form-control" placeholder="Input Invest Name">
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>Share Name</label>
                                                <select id="share_id" name="share_id" class="form-control">
                                                    <option value="">Choose Name...</option>
                                                    @foreach($ShareData as $iRow)
                                                    <option value="{{$iRow->id}}">{{$iRow->Share_name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>Lonaner Name</label>
                                                <input type="text" name="lonaner_name" class="form-control" placeholder="Lonaner Name">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Invest Amount</label>
                                                <input type="number" name="invest_amount" class="form-control" placeholder="Invest Amount" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <div class="form-group">
                                                    <label>Lonan Expair Date</label>
                                                    <input type="date" name="lonan_expair_date" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Profit System</label>
                                                <select name="profit_system" class="form-control">
                                                    <option selected="selected">Choose System...</option>
                                                    <option value="Day-By-Day">Day-By-Day</option>
                                                    <option value="Monthly">Monthly</option>
                                                    <option value="3-Month">3-Month</option>
                                                    <option value="6-Month">6-Month</option>
                                                    <option value="Yearly">Yearly</option>
                                                    <option value="One-time">One-time</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <div class="form-group">
                                                    <label>Profit Amount</label>
                                                    <input type="number" name="Profit_amount" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>About Invest Short Explain:</label>
                                            <textarea name="about_invest_explain" class="form-control h-150px" rows="6" id="comment"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Add Invest</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection