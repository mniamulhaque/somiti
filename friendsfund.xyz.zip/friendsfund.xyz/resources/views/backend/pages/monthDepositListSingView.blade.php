@extends('backend.layout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Deposit</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Collect</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Total Member</div>
                                            <div class="stat-digit gradient-3-text">{{count($invoicMemberData)}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-3" style="width: 50%;" role="progressbar"><span class="sr-only">50% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Due Member</div>
                                            <div class="stat-digit gradient-4-text">{{count($invoicMemberDueData)}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-4" style="width: 40%;" role="progressbar"><span class="sr-only">40% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Paid Member</div>
                                            <div class="stat-digit gradient-4-text"> {{count($invoicMemberData) - count($invoicMemberDueData)}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-4" style="width: 15%;" role="progressbar"><span class="sr-only">15% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">collected amount</div>
                                            <div class="stat-digit gradient-4-text"><i class="fa fa-usd"></i> {{$customerpaidAmount->sum('share_amount')}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-4" style="width: 15%;" role="progressbar"><span class="sr-only">15% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">@if(Session::has('message'))
                                <div class="alert alert-success" role="alert">
                                  {{Session::get('message')}}
                                </div>
                                @else
                                {{$invoicData->invoice_date}}
                                @endif Amount Collect</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Id</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Runing Month<br>Due</th>
                                                <th>Previous Months<br>Due</th>
                                                <th>Share Price</th>
                                                <th>Total Share</th>
                                                <th>Total Amount<br>Due</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             @foreach($invoicMemberData as $key=>$MemInRow)

                                             @php
                                             if($MemInRow->payment == 0){
                                                $runingMo = $MemInRow->share_amount;
                                            }else{
                                                $runingMo = 0;
                                            }

                                            $memberPreDue = App\memberInvoice::where('member_id',$MemInRow->member_id)->where('payment',0)->where('share_id',$MemInRow->share_id)->where('invoice_date_id','!=',$MemInRow->invoice_date_id)->sum('share_amount');
                                            @endphp
                                    <tr>
                                        <td>{{$key++}}</td>
                                        <td>{{$MemInRow->invoice_date_id}}</td>
                                        <td>{{$MemInRow->selectMember->name}}</td>
                                        <td>{{$MemInRow->selectMember->mobile}}</td>
                                        <td>{{$runingMo}}</td>
                                        <td id="loop">{{$memberPreDue}}</td>
                                        <td>{{$MemInRow->sharePrice->share_amount}}</td>
                                        <td>{{$MemInRow->share_amount / $MemInRow->sharePrice->share_amount}}</td>
                                        <td>
                                            {{$memberPreDue+$runingMo}}
                                        </td>
                                        <td>
                                             @if($MemInRow->payment == 0)
                                            <a href="{{url('payment_create/'.$MemInRow->id)}}">Pay</a>
                                            @else
                                            Complated
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection