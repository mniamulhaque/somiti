@extends('backend.layout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Deposit</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Collect</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Total Invoice Quantity</div>
                                            <div class="stat-digit gradient-3-text">{{count($invoicMemberData)}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-3" style="width: 50%;" role="progressbar"><span class="sr-only">50% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Total Paid Quantity</div>
                                            @php
                                            $dueMember = count($invoicMemberData->where('payment','>',0));
                                            $persondueMember = $dueMember/100;
                                            @endphp
                                            <div class="stat-digit gradient-4-text">{{$dueMember." / ".count($invoicMemberData)}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-4" style="width: {{$persondueMember}}%;" role="progressbar"><span class="sr-only">{{$dueMember}} Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Total Deposit amount</div>
                                            <div class="stat-digit gradient-4-text"> {{$invoicMemberData->sum('payment')}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Total Due amount</div>
                                            <div class="stat-digit gradient-4-text"><i class="fa fa-taka"></i> {{$invoicMemberData->sum('share_amount')-$invoicMemberData->sum('payment')}}</div>
                                        </div>
                                        <div class="progress mb-3">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Month</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Runing Month<br>Due</th>
                                                <th>Previous Months<br>Due</th>
                                                <th>Share Name</th>
                                                <th>Share Price</th>
                                                <th>Total Share</th>
                                                <th>Total Amount<br>Due</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             @foreach($invoicMemberData as $key=>$MemInRow)

                                             @php
                                             if($MemInRow->payment == 0){
                                                $runingMo = $MemInRow->share_amount;
                                            }else{
                                                $runingMo = 0;
                                            }

                                            $memberPreDue = App\memberInvoice::where('member_id',$MemInRow->member_id)->where('payment',0)->where('share_id',$MemInRow->share_id)->where('invoice_date_id','!=',$MemInRow->invoice_date_id)->sum('share_amount');
                                            @endphp
                                    <tr>
                                        <td>{{++$key}}</td>
                                        <td>{{$MemInRow->invoice_date}}</td>
                                        <td>{{$MemInRow->selectMember->name}}</td>
                                        <td>{{$MemInRow->selectMember->mobile}}</td>
                                        <td>{{$runingMo}}</td>
                                        <td id="loop">{{$memberPreDue}}</td>
                                        <td>{{$MemInRow->sharePrice->Share_name}}</td>
                                        <td>{{$MemInRow->sharePrice->share_amount}}</td>
                                        <td>{{$MemInRow->share_amount / $MemInRow->sharePrice->share_amount}}</td>
                                        <td>
                                            {{$memberPreDue+$runingMo}}
                                        </td>
                                        <td>
                                            @if($MemInRow->payment == 0)
                                            <a href="{{url('payment_create/'.$MemInRow->id)}}">Pay</a>
                                            @else
                                            Complated
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection