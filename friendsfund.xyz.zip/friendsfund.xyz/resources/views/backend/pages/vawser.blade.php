<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    
    <!-- theme meta -->
    <meta name="theme-name" content="quixlab" />
  
    <title>Deposit club</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{asset('backend_assets/images/favicon.png')}}">
    <link href="{{asset('backend_assets/plugins/tables/css/datatable/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link href="{{asset('backend_assets/css/style.css')}}" rel="stylesheet">

    <style>
      /* style sheet for “letter” printing */
      .content-body {
    margin-left: 0rem; 
          z-index: 0;
      }

    @media print {
          .no_print{
            display: none;
          }
         
      }
  </style>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->
        <!--**********************************
            Content body start
        ***********************************-->
    <div class="content-body">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card" id="section-to-print">
                    <div class="card-body">
                        <h4>
                            <img src="{{asset('backend_assets/images/ffflogo.png')}}" alt="" height="100" width="100"> Friends Fund.
                            <small class="float-right">Date: {{date('d-m-Y')}}</small>
                          </h4>
                         <!-- info row -->
                          <div class="row">
                            <div class="col-md-4">
                              From
                              <address>
                                <strong>Friends Fund Family.</strong><br>
                                Daudkandi Baar, Daudkandi-3516<br>
                                Daudkandi, Cumilla<br>
                                Phone: +880 1837180701<br>
                                Email: info@friendsfund.com
                              </address>
                            </div>
                            <!-- /.col -->
                            <div class="col-md-4">
                              To
                              <address>
                                <strong>{{$memverInfo->name}}</strong><br>
                                {{$memverInfo->addr}}<br>
                                {{$memverInfo->upazila}},{{$memverInfo->district}}<br>
                                Call: {{$memverInfo->mobile}},{{$memverInfo->Alternative_number}}<br>
                                Email: @if($memverInfo->email == null || $memverInfo->email == 0) not-email@mail.com @else {{$memverInfo->email}} @endif
                              </address>
                            </div>
                            <!-- /.col -->
                            <div class="col-md-4">
                              <b>Invoice #{{$invoiceInfo->invoice_date_id}}</b><br>
                              <a class="btn btn-outline-primary btn-rounded pl-5 pr-5 mt-2 mb-2" style="font-size:18px;"><b> @if(count($invoicMemberAllDue1) == 0 ) Paid @else Unpaid @endif </b></a><br>
                              <b>Payment Due:</b> {{$invoiceInfo->invoice_date}}<br>
                              <b>Member ID:</b> {{$memverInfo->member_id}}
                            </div>
                            <!-- /.col -->
                          </div>
                          <!-- /.row -->
                        <!-- Table row -->
                          <div class="row mt-5">
                            <div class="col-md-12 table-responsive">
                              <table class="table table-striped">
                                <thead>
                                <tr>
                                  <th>Qty</th>
                                  <th>Payment Date</th>
                                  <th>Due Month</th>
                                  <th>Package</th>
                                  <th>Line Rent</th>
                                </tr>
                                </thead>
                                <tbody>
                                  @foreach($invoicMemberAllDue as $D_dat)

                                <tr>
                                  <td>1</td>
                                  <td>{{$D_dat->pay_date}}</td>
                                  <td>{{$D_dat->invoice_date}}</td>
                                  <td>{{$D_dat->sharePrice->Share_name}}</td>
                                  <td>
                                    {{$D_dat->share_amount}}
                                  </td>
                                </tr>
                                @endforeach
                                <tr>
                                  <td colspan="6"></td>
                                </tr>
                                </tbody>
                              </table>
                            </div>
                            <!-- /.col -->
                          </div>
                          <!-- /.row -->
                        <div class="row">
                        <!-- accepted payments column -->
                        <div class="col-md-6">
                          <p class="lead">Payment Rule:</p>
                          

                          <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                            Payment Gateway Coming Soon
                          </p>
                        </div>
                        <!-- /.col -->
                        <div class="col-md-6">
                          <p class="lead">Amount Count Month -{{$invoiceInfo->invoice_date}}</p>

                          <div class="table-responsive">
                            <table class="table">
                              <tr>
                                <th style="width:50%">{{$invoiceInfo->invoice_date}} Month Due: </th>
                                <td>@if($invoiceInfo->payment > 0 && $pre_due1 > 0) 0 @else {{$invoiceInfo->share_amount}} @endif</td>
                              </tr>
                              <tr>
                                <th>Previous Month Due : </th>
                                <td>@if($invoiceInfo->payment == 0 && $pre_due1 == 0) 0 @else {{$pre_due}} @endif</td>
                              </tr>
                              <tr>
                                <th>Another Due:</th>
                                <td>00</td>
                              </tr>
                              <tr>
                                <th>@if(count($invoicMemberAllDue1) == 0 )Paid @endif
                                Total:</th>
                                <td>@if($invoiceInfo->payment == 0 && $pre_due1 == 0) {{$invoiceInfo->share_amount}}@elseif($invoiceInfo->payment > 0 && $pre_due1 > 0) {{$pre_due}}@else {{$invoiceInfo->share_amount + $pre_due}}@endif</td>
                              </tr>
                            </table>
                          </div>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <div class="row mt-5">
                        <div class="col-12">
                          <div class="RecevSing float-right" style="margin-right:70px;">
                            <hr style="width:100%;">
                            <h4>Received By</h4>

                          </div>
                        </div>
                      </div>

                      <div class="row no-print">
                        <div class="col-12">
                          <button onclick="window.print()" class="btn btn-default no_print"> Print </button>

                          <a href="javascript:history.go(-2)" class="btn btn-primary float-right no_print" style="margin-right: 5px; margin-top: 7px;">Cancel
                          </a>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container -->
</div>
  <!--**********************************
            Content body end
        ***********************************-->
  <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer no-print">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="https://niamul.com">Niamul Haque</a> 2022</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="{{asset('backend_assets/plugins/common/common.min.js')}}"></script>
    <script src="{{asset('backend_assets/js/custom.min.js')}}"></script>
    <!-- Table Database -->



    <script src="{{asset('backend_assets/js/dashboard/dashboard-1.js')}}"></script>


</body>

</html>
