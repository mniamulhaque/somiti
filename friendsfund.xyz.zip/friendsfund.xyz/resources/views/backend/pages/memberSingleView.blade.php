@extends('backend.layout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Member Details</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                            @php
                                            $buyingD = App\buyingTable::where('member_id',$userData->id)->get();
                                            @endphp
                                            <tr>
                                                <th>Member Id</th>
                                                <td>{{$userData->member_id}}</td>
                                            </tr>
                                            <tr>
                                                <th>Name</th>
                                                <td>{{$userData->name}}</td>
                                            </tr>
                                            <tr>
                                                <th>Father Name</th>
                                                <td>{{$userData->father_name}}</td>
                                            </tr>
                                            <tr>
                                                <th>Addr</th>
                                                <td>{{$userData->addr.",".$userData->upazila.",".$userData->district.",".$userData->Divi}}</td>
                                            </tr>
                                            <tr>
                                                <th>Mobile</th>
                                                <td>{{$userData->mobile}}</td>
                                            </tr>
                                            <tr>
                                                <th>Alternative Number</th>
                                                <td>{{$userData->Alternative_number}}</td>
                                            </tr>
                                            @foreach($buyingD as $row)
                                            <tr>
                                                <td style="background:tomato;color: #fff;" colspan="2">@if(count($buyingD) == 0)
                                                 Not Buyer
                                                @else
                                                {{$row->sharePrice->Share_name}}
                                                @endif

                                            </td>
                                            </tr>
                                            <tr>
                                                <th>Share Name</th>
                                                <td>
                                                @if(count($buyingD) == 0)
                                                 Not Buyer
                                                @else
                                                {{$row->sharePrice->Share_name}}
                                                @endif</td>
                                            </tr>
                                            <tr>
                                                <th>Share Quntity</th>
                                                <td>
                                                @if(count($buyingD) == 0)
                                                 Not Buyer
                                                @else
                                                {{$row->shareQuantity}}
                                                @endif</td>
                                            </tr>
                                            <tr>
                                                <th>Share Price</th>
                                                 <td>
                                               @if(count($buyingD) == 0)
                                                 No Amount
                                                @else
                                                {{$row->sharePrice->share_amount}}
                                                @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Total Share Amount</th>
                                                 <td>
                                               @if(count($buyingD) == 0)
                                                 No Amount
                                                @else
                                                {{$row->sharePrice->share_amount." * ".$row->shareQuantity." = ".$row->share_amount}}
                                                @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Share Buying Date</th>
                                                <td>
                                               @if(count($buyingD) == 0)
                                                 No Date
                                                @else
                                                {{$row->buying_date}}
                                                @endif
                                                </td>
                                            </tr>
                                            @endforeach
                                            <tr>
                                                <td colspan="2"><hr style="border:2px solid tomato;"/>
                                            </td>
                                            <tr>
                                                <th>Gender</th>
                                                <td>{{$userData->gender}}</td>
                                            </tr>
                                            <tr>
                                                <th>Date of Birth</th>
                                                <td>{{$userData->dob}}</td>
                                            </tr>
                                            <tr>
                                                <th>Nid Number</th>
                                                <td>{{$userData->nid}}</td>
                                            </tr>
                                            <tr>
                                                <th>Gender</th>
                                                <td>{{$userData->gender}}</td>
                                            </tr>
                                            <tr>
                                                <th colspan="2">Information Picture</th>
                                            </tr>
                                            <tr>
                                                <td><img style="height: 100px; width: 100px;" src="{{asset('backend_assets/images/member/'.$userData->photo)}}" alt=""></td>
                                                <td><img style="height: 100px; width: 100px;" src="{{asset('backend_assets/images/member/'.$userData->nid_photo)}}" alt=""></td>
                                            </tr>
                                            <tr>
                                                <th colspan="2">Nominee Information</th>
                                            </tr>
                                            <tr>
                                                <th>Nominee Name</th>
                                                <td>{{$userData->nominiName}}</td>
                                            </tr>
                                            <tr>
                                                <th>Nominee Relation</th>
                                                <td>{{$userData->nominiSomorko}}</td>
                                            </tr>
                                            <tr>
                                                <th colspan="2">Nominee Information Picture</th>
                                            </tr>
                                            <tr>
                                                <td><img style="height: 100px; width: 100px;" src="{{asset('backend_assets/images/member/'.$userData->NominiPhoto)}}" alt=""></td>
                                                <td><img style="height: 100px; width: 100px;" src="{{asset('backend_assets/images/member/'.$userData->NominiNid_photo)}}" alt=""></td>
                                            </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection