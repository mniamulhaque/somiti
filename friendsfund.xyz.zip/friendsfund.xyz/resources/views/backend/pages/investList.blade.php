@extends('backend.layout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Table</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Name</th>
                                                <th>Lonaner Name</th>
                                                <th>Invest Amount</th>
                                                <th>Profit System</th>
                                                <th>Profit Amount</th>
                                                <th>Start date</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($investData as $key=>$ShRow)
                                            <tr>
                                                <td>{{++$key}}</td>
                                                <td>{{$ShRow->invest_name}}</td>
                                                <td>{{$ShRow->lonaner_name}}</td>
                                                <td>{{$ShRow->invest_amount}}</td>
                                                <td>{{$ShRow->profit_system}}</td>
                                                <td>{{$ShRow->Profit_amount}}</td>
                                                <td>12/03/2030</td>
                                                
                                                <td><a href="{{url('/shareView/'.$ShRow->id)}}">View</a></td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection