@extends('backend.layout.master')
  @section('body')
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Member</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Add New Member</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">New Member Form</h4>
                                <h4 class="card-title">
                                   @if($errors->has('name'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('name')}}
                                        </div>
                                    @elseif($errors->has('father_name'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('father_name')}}
                                        </div>
                                    @elseif($errors->has('addr'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('addr')}}
                                        </div>
                                    @elseif($errors->has('nid'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('nid')}}
                                        </div>
                                    @elseif($errors->has('dob'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('dob')}}
                                        </div>
                                    @elseif($errors->has('mobile'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('mobile')}}
                                        </div>
                                    @elseif($errors->has('Alternative_number'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('Alternative_number')}}
                                        </div>
                                    @elseif($errors->has('profesion'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('profesion')}}
                                        </div>
                                    @elseif($errors->has('upazila'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('upazila')}}
                                        </div>
                                    @elseif($errors->has('district'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('district')}}
                                        </div>
                                    @elseif($errors->has('Divi'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('Divi')}}
                                        </div>
                                    @elseif($errors->has('password'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('password')}}
                                        </div>
                                    @elseif($errors->has('gender'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('gender')}}
                                        </div>
                                    @elseif($errors->has('nominiName'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('nominiName')}}
                                        </div>
                                    @elseif($errors->has('nominiSomorko'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('nominiSomorko')}}
                                        </div>
                                    @elseif($errors->has('NominiPhoto'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('NominiPhoto')}}
                                        </div>
                                    @elseif($errors->has('NominiNid_photo'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('NominiNid_photo')}}
                                        </div>
                                    @elseif(Session::has('message'))
                                        <div class="alert alert-success" role="alert">
                                          {{Session::get('message')}}
                                        </div>
                                    @endif
                                 </h4>
                                <div class="basic-form">
                                    <form class="mt-5 mb-5 login-input" method="POST" action="{{ url('/addMember') }}" enctype="multipart/form-data">
                                     @csrf
                                        <div class="form-row">
                                            <div class="form-group col-md-2">
                                                <label>Member Id</label>
                                                <input id="member_id" name="member_id" type="number" class="form-control"  value="{{$rollno}}" required readonly>
                                            </div>
                                            <div class="form-group col-md-5">
                                                <label>Name</label>
                                                <input id="name" name="name" type="text" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-5">
                                                <label>Father's Name</label>
                                                <input type="text" name="father_name" class="form-control" required>
                                                
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Address</label>
                                                <input type="text" name="addr" class="form-control" required>
                                                
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Nid No</label>
                                                <input type="number" name="nid" class="form-control" required>
                                                
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Gender</label>
                                                <select id="gender" name="gender" class="form-control">
                                                    <option selected="selected">Choose Gender...</option>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>DOB</label>
                                                <input type="date" name="dob" class="form-control" required>
                                                
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Mobile No</label>
                                                <input type="number" name="mobile" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Alternative Number</label>
                                                <input type="number" name="Alternative_number" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Profession</label>
                                                <input type="text" name="profesion" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Member Photo</label>
                                                 <input type="file" class="form-control-file" name="photo" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Nid Photo(Back and frond)</label>
                                                <input type="file" class="form-control-file" name="nid_photo" required>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label>Upazila</label>
                                                <input type="text" name="upazila" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>District</label>
                                                <input type="text" name="district" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>Division</label>
                                                <input type="text" name="Divi" class="form-control" required>
                                            </div>
                                        </div>
                                        <hr>
                                        <h4>Nomoni Information...</h4>
                                        <hr>
                                         <div class="form-row">
                                            <div class="form-group col-md-3">
                                                <label>Nomini Name</label>
                                                <input type="text" name="nominiName" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label>Nomini Somorko</label>
                                                <input type="text" name="nominiSomorko" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label>Nomini Photo</label>
                                                 <input type="file" class="form-control-file" name="NominiPhoto" required>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label>Nomini Nid Photo(Back and frond)</label>
                                                <input type="file" class="form-control-file" name="NominiNid_photo" required>
                                            </div>
                                        </div>
                                        <hr>
                                        <h4>Login Information...</h4>
                                        <hr>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <input id="email" type="text" class="form-control"  placeholder="Email" name="email"/>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <input id="password" class="form-control"   type="password" placeholder="password" name="password" required/>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Add Member</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection