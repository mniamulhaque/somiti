@extends('backend.layout.master')
  @section('body')
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Share</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Add New Share</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">New Share Form</h4>
                                  <h4 class="card-title">
                                   @if($errors->has('Share_name'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('Share_name')}}
                                        </div>
                                    @elseif($errors->has('share_amount'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('share_amount')}}
                                        </div>
                                    @elseif($errors->has('share_expair_date'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('share_expair_date')}}
                                        </div>
                                    @elseif($errors->has('about_share_explain'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('about_share_explain')}}
                                        </div>
                                    @elseif($errors->has('share_photo'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('share_photo')}}
                                        </div>
                                    @elseif(Session::has('message'))
                                        <div class="alert alert-success" role="alert">
                                          {{Session::get('message')}}
                                        </div>
                                    @endif
                                 </h4>
                                <div class="basic-form">
                                    <form class="mt-5 mb-5 login-input" method="POST" action="{{ url('/addShare') }}" enctype="multipart/form-data">
                                     @csrf
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Share Name</label>
                                                <input type="text" name="Share_name" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Share Amount</label>
                                                <input type="number" name="share_amount" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Share Limit (Optional)</label>
                                                <input type="number" name="share_limit" class="form-control">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <div class="form-group">
                                                    <label>Share Expair Date</label>
                                                    <input type="date" name="share_expair_date" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>About Share Explain:</label>
                                                <textarea name="about_share_explain" class="form-control h-150px" rows="6" id="comment" required></textarea>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Share Banner Image(600px by 300px)</label>
                                                 <input type="file" class="form-control-file" name="share_photo" required>
                                            </div>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-dark">Add Share</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection