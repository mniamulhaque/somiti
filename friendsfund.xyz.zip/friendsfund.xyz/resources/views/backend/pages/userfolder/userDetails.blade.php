@extends('backend.pages.userfolder.userlayout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="container mt-3">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="card-title">{{$shareBuying->sharePrice->Share_name}}</h5>
                            </div>
                            <img class="img-fluid" src="{{asset('backend_assets/images/'.$shareBuying->sharePrice->share_photo)}}" alt="">
                            <div class="card-body">
                                <p class="card-text">{{$shareBuying->sharePrice->about_share_explain}}</p>
                            </div>
                            <div class="card-footer border-0 bg-transparent">
                                <div class="basic-list-group">
                                    <ul class="list-group">
                                        @php
                                        $myInvest = (($shareBuying->shareInvest->sum('invest_amount')) / ($shareBuying->totalShare->sum('shareQuantity'))) * $shareBuying->shareQuantity
                                        @endphp
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total My Balance <span class="badge badge-primary badge-pill">{{round(($shareBuying->MemberInvoicee->sum('payment')) - $myInvest, 2)}} ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Paid Quantity <span class="badge badge-primary badge-pill">{{count($shareBuying->MemberInvoicee->where('payment','>',0))}}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Paid Amount <span class="badge badge-primary badge-pill">{{$shareBuying->MemberInvoicee->sum('payment')}} ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Due Quantity <span class="badge badge-primary badge-pill">{{count($shareBuying->MemberInvoicee)-count($shareBuying->MemberInvoicee->where('payment','>',0))}}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Due Amount <span class="badge badge-primary badge-pill">{{$shareBuying->MemberInvoicee->sum('share_amount') - $shareBuying->MemberInvoicee->sum('payment')}} ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Share Price <span class="badge badge-primary badge-pill">{{$shareBuying->sharePrice->share_amount}} ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Share Quantity <span class="badge badge-primary badge-pill">{{$shareBuying->shareQuantity}}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Share Amount <span class="badge badge-primary badge-pill">{{$shareBuying->share_amount}} ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Invest <span class="badge badge-primary badge-pill">{{round($myInvest, 2)}} ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Profit <span class="badge badge-primary badge-pill">{{round((($shareBuying->InvestProfit->sum('Profit_amount')) / $shareBuying->totalShare->sum('shareQuantity'))*$shareBuying->shareQuantity, 2)}} ৳</span>
                                        </li>
                                    </ul>
                                </div>
                                <hr>
                                <hr>
                                <h4 class="card-title mt-5">My Deposit List</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Month/Year</th>
                                                <th>Share Amount</th>
                                                <th>Paid/Unpaid</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($invoicMemberData as $key=>$row)
                                            @php
                                            $date=date_create($row->invoice_date);
                                            $datee= date_format($date,"F/Y");
                                            @endphp
                                            <tr>
                                                <td>{{++$key}}</td>
                                                <td>{{$datee}}</td>
                                                <td>{{$row->share_amount}}</td>
                                                <td>
                                                    @if($row->payment > 0)
                                                    <i class="fa fa-circle-o text-success  mr-2"></i> Paid
                                                    @else
                                                    <i class="fa fa-circle-o text-warning  mr-2"></i> Unpaid
                                                    @endif
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
    @endsection