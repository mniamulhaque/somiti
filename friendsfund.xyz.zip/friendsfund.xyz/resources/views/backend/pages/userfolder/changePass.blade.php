 @extends('backend.pages.userfolder.userlayout.master')
  @section('body')
<div class="content-body">
<div class="container-fluid mt-3">
  <div class="login-form-bg h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100">
                <div class="col-xl-6">
                    <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5">
                                <a class="text-center" href="#"> <h4>Change Password</h4></a>
                                <h4>
                                  @if($errors->has('current_password'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('current_password')}}
                                        </div>
                                    @elseif($errors->has('password'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('password')}}
                                        </div>
                                    @elseif($errors->has('password_confirmation'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('password_confirmation')}}
                                        </div>
                                    @elseif(Session::has('error'))
                                        <div class="alert alert-danger" role="alert">
                                          {{Session::get('error')}}
                                        </div>
                                    @elseif(Session::has('message'))
                                        <div class="alert alert-success" role="alert">
                                          {{Session::get('message')}}
                                        </div>
                                    @endif
                                </h4>
        
                                <form class="mt-5 mb-5 login-input" method="POST" action="{{url('/member/changePassStor')}}">
                                    @csrf
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Current Password" name="current_password">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="New Password" name="password">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation">
                                    </div>
                                    <button class="btn login-form__btn submit w-100">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
  @endsection