@extends('backend.pages.userfolder.userlayout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="container-fluid mt-3">
                <div class="row">

                    @foreach($shareBuying as $row)
                    <div class="col-md-4 col-sm-6">
                         <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="card-title">{{$row->sharePrice->Share_name}}</h5>
                                <h6 class="card-subtitle mb-2 text-muted">ধৈর্য আর চেষ্টাই আপনার ভাগ্য খুলে দিতে পারে</h6>
                            </div>
                            <img class="img-fluid" src="{{asset('backend_assets/images/'.$row->sharePrice->share_photo)}}" alt="image">
                            <div class="card-body">
                                <p class="card-text">{{substr($row->sharePrice->about_share_explain, 0, 300)}}<a href="{{url('/userdetails/'.$row->share_id)}}"> >>>>More>>>></a></p>
                            </div>
                            <div class="card-footer border-0 bg-transparent">
                                <div class="row">
                                    <div class="col-4 border-right-1 pt-3">
                                        <a class="text-center d-block text-muted" href="javascript:void()">
                                            <i class="fa fa-money gradient-1-text" aria-hidden="true"></i>
                                            <p class="">Paid Amount</p>
                                            <h5 class="">{{$row->MemberInvoicee->sum('payment')}} ৳</h5>
                                        </a>
                                    </div>
                                    <div class="col-4 border-right-1 pt-3"><a class="text-center d-block text-muted" href="javascript:void()">
                                        <i class="fa fa-money gradient-3-text"></i>
                                            <p class="">Due Amount</p>
                                            <h5 class="">{{$row->MemberInvoicee->sum('share_amount') - $row->MemberInvoicee->sum('payment')}} ৳</h5>
                                        </a>
                                    </div>
                                    <div class="col-4 pt-3"><a class="text-center d-block text-muted" href="javascript:void()">
                                        <i class="fa fa-money gradient-4-text"></i>
                                            <p class="">My Share</p>
                                            <h5 class="">{{$row->shareQuantity}}</h5>
                                        </a>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    @php
                                    $myInvest = (($row->shareInvest->sum('invest_amount')) / ($row->totalShare->sum('shareQuantity'))) * $row->shareQuantity
                                    @endphp
                                    <div class="col-4 border-right-1 pt-3">
                                        <a class="text-center d-block text-muted" href="javascript:void()">
                                            <i class="fa fa-money gradient-1-text" aria-hidden="true"></i>
                                            <p class="">My Balance</p>
                                            <h5 class="">{{round(($row->MemberInvoicee->sum('payment')) - $myInvest, 2)}} ৳</h5>
                                        </a>
                                    </div>
                                    <div class="col-4 border-right-1 pt-3"><a class="text-center d-block text-muted" href="javascript:void()">
                                        <i class="fa fa-money gradient-3-text"></i>
                                            <p class="">My Invest</p>
                                            <h5 class="">{{round($myInvest, 2)}} ৳</h5>
                                        </a>
                                    </div>
                                    <div class="col-4 pt-3"><a class="text-center d-block text-muted" href="javascript:void()">
                                        <i class="fa fa-money gradient-4-text"></i>
                                            <p class="">My Profit</p>
                                            <h5 class="">{{round((($row->InvestProfit->sum('Profit_amount')) / $row->totalShare->sum('shareQuantity'))*$row->shareQuantity, 2)}} ৳</h5>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach


                    <div class="col-md-4 col-sm-6">
                        <div class="card pt-5 pb-5">
                            <div class="card-header bg-white">
                                <h5 class="card-title">New Share With Profit Coming Soon</h5>
                            </div>
                            <div class="card-body pt-5 pb-5">
                                <div class="text-center pt-5 pb-5">
                                    <span class="display-4"><i class="icon-plus gradient-4-text" style="font-size: 200px;"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                         <div class="card">
                            
                        </div>
                    </div>
                </div>
               
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
    @endsection