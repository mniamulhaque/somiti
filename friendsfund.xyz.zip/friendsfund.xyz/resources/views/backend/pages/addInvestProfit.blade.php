@extends('backend.layout.master')
  @section('body')
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Profit</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Add Profit</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Profit Form</h4>
                                  <h4 class="card-title">
                                   @if($errors->has('invest_name'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('invest_name')}}
                                        </div>
                                    @elseif($errors->has('Profit_amount'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('Profit_amount')}}
                                    </div>
                                    @elseif($errors->has('entre_date'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('entre_date')}}
                                    </div>
                                    @elseif($errors->has('lonaner_name'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('lonaner_name')}}
                                    </div>
                                    @elseif(Session::has('message'))
                                        <div class="alert alert-success" role="alert">
                                          {{Session::get('message')}}
                                        </div>
                                    @endif
                                 </h4>
                                <div class="basic-form">
                                    <form method="POST" action="{{ url('/addInvestProfit') }}">
                                        @csrf
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label>Invest Name</label>
                                                <select id="invest_id" name="invest_id" class="form-control">
                                                    <option value="">Choose Name...</option>
                                                    @foreach($investData as $iRow)
                                                    <option value="{{$iRow->id}}">{{$iRow->invest_name}}</option>
                                                    @endforeach
                                                </select>
                                                <input id="invest_name" type="hidden" name="invest_name">
                                                <input id="share_name" type="hidden" name="share_name">
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>Share Name</label>
                                                <select id="share_id" name="share_id" class="form-control" readonly>
                                                    <option selected="selected" value="">Choose Name...</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>Lonaner Name</label>
                                                <select id="lonaner_name" name="lonaner_name" class="form-control" readonly>
                                                    <option selected="selected" value="">Choose Name...</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Invest Amount</label>
                                                <input id="invest_amount" type="number" name="invest_amount" class="form-control" placeholder="Invest Amount" readonly>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <div class="form-group">
                                                    <label>Lonan Expair Date</label>
                                                    <input type="date" id="lonan_expair_date" name="lonan_expair_date" class="form-control" readonly>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label>Profit System</label>
                                                <select id="profit_system" name="profit_system" class="form-control" readonly>
                                                    <option selected="selected">Choose System...</option>
                                                   
                                                </select>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <div class="form-group">
                                                    <label>Profit Previous Due Qiantity</label>
                                                    <input type="number" id="profit_previous_due" name="profit_previous_due" class="form-control" readonly>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <div class="form-group">
                                                    <label>Total Profit Paid Qiantity</label>
                                                    <input type="number" id="Total_profit_paid_qiantity" name="Total_profit_paid_qiantity" class="form-control" readonly>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label>Fixt Profit Amount Per Session</label>
                                                <input type="text" id="fixt_profit_amount" name="fixt_profit_amount" class="form-control" readonly>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <div class="form-group">
                                                    <label>Input Profit Amount</label>
                                                    <input type="number" name="Profit_amount" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <div class="form-group">
                                                    <label>Entre Date</label>
                                                    <input type="date" id="entre_date" name="entre_date" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Profit Details:</label>
                                            <textarea name="profit_details" class="form-control h-150px" rows="6" id="comment"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection