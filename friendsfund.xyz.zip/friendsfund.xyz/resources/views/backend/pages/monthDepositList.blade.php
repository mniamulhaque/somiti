@extends('backend.layout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
    <div class="content-body">
    <div class="row page-titles mx-0">
        <div class="col p-md-0">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
            </ol>
        </div>
    </div>
    <!-- row -->

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                    <a href="{{url('/createInvoic_month/'.$share_id)}}" class="btn btn-Primary mb-2">Create New Deposit Month</a>
                        <h4 class="card-title">Data Table</h4>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th>Si</th>
                                        <th>Id</th>
                                        <th>Deposit Created Month</th>
                                        <th>Total Member</th>
                                        <th>Due Member</th>
                                        <th>Paid Member</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($invoic as $key=>$InRow)
                                    <tr>
                                        <td>{{++$key}}</td>
                                        <td>{{$InRow->bill_id}}</td>
                                        @php
                                        $date = date_create($InRow->invoice_date);
                                        $datee = date_format($date,"F - Y");
                                        @endphp
                                        <td>{{$datee}}</td>
                                        <td>{{count($InRow->invoiceMember)}}</td>
                                        <td>{{count($InRow->invoiceMemberDue)}}</td>
                                        <td>{{count($InRow->invoiceMember) - count($InRow->invoiceMemberDue)}}</td>
                                        <td><a href="{{url('/monthDepositListSingleView/'.$InRow->bill_id)}}">View</a></td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container -->
</div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection