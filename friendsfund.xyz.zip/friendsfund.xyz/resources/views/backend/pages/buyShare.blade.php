@extends('backend.layout.master')
  @section('body')
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Share</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Buy Share</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Buy Share Form</h4>
                                <h4 class="card-title">
                                   @if($errors->has('member_id'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('member_id')}}
                                        </div>
                                    @elseif($errors->has('share_id'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('share_id')}}
                                        </div>
                                @elseif($errors->has('shareQuantity'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('shareQuantity')}}
                                        </div>
                                @elseif($errors->has('buying_date'))
                                      <div class="alert alert-danger" role="alert">
                                    {{$errors->first('buying_date')}}
                                        </div>
                                    @elseif(Session::has('error'))
                                        <div class="alert alert-danger" role="alert">
                                          {{Session::get('error')}}
                                        </div>
                                    @elseif(Session::has('message'))
                                        <div class="alert alert-success" role="alert">
                                          {{Session::get('message')}}
                                        </div>
                                    @endif
                                 </h4>
                                <div class="basic-form">
                                    <form class="forms-sample" action="{{url('/buyshare')}}" method="POST">
                                        @csrf
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Member Name</label>
                                                <select id="member_id" name="member_id" class="form-control">
                                                    <option value="">Choose Name...</option>
                                                    @foreach($memberData as $mRow)
                                                    <option value="{{$mRow->id}}">{{$mRow->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Share Name</label>
                                                <select id="share_id" name="share_id" class="form-control">
                                                    <option value="">Choose Name...</option>
                                                    @foreach($ShareData as $sRow)
                                                    <option value="{{$sRow->id}}">{{$sRow->Share_name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Share Quantity</label>
                                                <input type="number" name="shareQuantity" class="form-control" placeholder="Type Share Quantity">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <div class="form-group">
                                                    <label>Buying Date</label>
                                                    <input type="date" name="buying_date" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Buy</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection