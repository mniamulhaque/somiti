@extends('backend.layout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Table</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Invest Name</th>
                                                <th>Loner Name</th>
                                                <th>Entre Date</th>
                                                <th>Fixt Profit<br>Amount</th>
                                                <th>Receved Profit<br>Amount</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                              @foreach($investProfitData as $key=>$ShRow)
                                            <tr>
                                                <td>{{++$key}}</td>
                                                <td>{{$ShRow->invest_name}}</td>
                                                <td>{{$ShRow->lonaner_name}}</td>
                                                <td>{{$ShRow->entre_date}}</td>
                                                <td>{{$ShRow->fixt_profit_amount}}</td>
                                                <td>{{$ShRow->Profit_amount}}</td>
                                                
                                                <td><a href="{{url('/shareView/'.$ShRow->id)}}">View</a></td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection