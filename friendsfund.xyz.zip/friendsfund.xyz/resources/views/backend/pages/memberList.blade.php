@extends('backend.layout.master')
  @section('body')
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="navbarcreate">
                                    <ul class="nav_ul">
                                      <li><a class="activee" href="#home">Home</a></li>
                                      <li><a href="#news">News</a></li>
                                      <li><a href="#contact">Contact</a></li>
                                      <li style="float:right"><a href="#about">About</a></li>
                                    </ul>
                                </div>
                                <h4 class="card-title"></h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Name</th>
                                                <th>Father <br>Name</th>
                                                <th>Addr</th>
                                                <th>Mobile</th>
                                                <th>Alternative<br>Number</th>
                                                <th>Share <br>Quntity</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             @foreach($userData as $key=>$mRow)
                                             
                                            <tr>
                                                <td>{{++$key}}</td>
                                                <td>{{$mRow->name}}</td>
                                                <td>{{$mRow->father_name}}</td>
                                                <td>{{$mRow->addr}}</td>
                                                <td>{{$mRow->mobile}}</td>
                                                <td>{{$mRow->Alternative_number}}</td>
                                                <td>
                                                 @php
                                                    $buyingD = App\buyingTable::where('member_id',$mRow->id)->get();
                                                @endphp
                                               @if(count($buyingD) == 0)
                                                 Not Buyer
                                                @else
                                                @foreach($buyingD as $row)
                                                {{$row->sharePrice->Share_name." - ".$row->shareQuantity.' ,  '}}
                                                @endforeach
                                                @endif
                                                </td>
                                                <td><a href="{{url('/memberview/'.$mRow->id)}}">View</a></td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection