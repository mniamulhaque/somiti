@extends('backend.layout.master')
  @section('body')
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Invoice</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Create Month Invoice</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Create Month Invoice</h4>
                                  <h4 class="card-title">
                                   @if($errors->has('bill_id'))
                                        <div class="alert alert-danger" role="alert">
                                          {{$errors->first('bill_id')}}
                                        </div>
                                    @elseif($errors->has('invoice_date'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('invoice_date')}}
                                        </div>
                                    @elseif($errors->has('share_id'))
                                      <div class="alert alert-danger" role="alert">
                                          {{$errors->first('share_id')}}
                                        </div>
                                    @elseif(Session::has('error'))
                                        <div class="alert alert-danger" role="alert">
                                          {{Session::get('error')}}
                                        </div>
                                    @elseif(Session::has('message'))
                                        <div class="alert alert-success" role="alert">
                                          {{Session::get('message')}}
                                        </div>
                                    @endif
                                 </h4>
                                <div class="basic-form">
                                    <form class="mt-5 mb-5 login-input" method="POST" action="{{ url('/createInvoic_month') }}">
                                     @csrf
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>invoice_id</label>
                                                <input type="text"  name="bill_id" value="{{$invoice_Codate}}"  class="form-control">
                                                <input type="hidden"  name="share_id" value="{{$share_id}}">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Date</label>
                                                <input type="month" class="form-control" id="invoice_date" name="invoice_date">
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 @endsection