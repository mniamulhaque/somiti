@extends('layouts.master')
@section('body')
<!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5 wow fadeIn" data-wow-delay="0.1s">
      <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="2" aria-label="Slide 3"></button>
          <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="3" aria-label="Slide 4"></button>
          <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="4" aria-label="Slide 5"></button>
          <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="5" aria-label="Slide 6"></button>
          <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="6" aria-label="Slide 7"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="d-block w-100" src="{{asset('backend_assets/LandingPage/img/fffb1.jpg')}}" alt="Image" />
          </div>
          <div class="carousel-item">
            <img class="w-100" src="{{asset('backend_assets/LandingPage/img/fffb2.jpg')}}" alt="Image" />
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="{{asset('backend_assets/LandingPage/img/fffb3.jpg')}}" alt="Image" />
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="{{asset('backend_assets/LandingPage/img/fffb4.jpg')}}" alt="Image" />
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="{{asset('backend_assets/LandingPage/img/fffb5.jpg')}}" alt="Image" />
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="{{asset('backend_assets/LandingPage/img/fffb6.jpg')}}" alt="Image" />
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
    <!-- Carousel End -->

    <!-- About Start -->
    <div class="container-xxl py-5">
      <div class="container">
        <div class="row g-5">
          <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
            <div
              class="position-relative overflow-hidden rounded ps-5 pt-5 h-100"
              style="min-height: 400px"
            >
              <img
                class="position-absolute w-100 h-100"
                src="{{asset('backend_assets/LandingPage/img/about.jpg')}}"
                alt=""
                style="object-fit: cover"
              />
              <div
                class="position-absolute top-0 start-0 bg-white rounded pe-3 pb-3"
                style="width: 200px; height: 200px"
              >
                <div
                  class="d-flex flex-column justify-content-center text-center bg-primary rounded h-100 p-3"
                >
                  <h1 class="text-white mb-0">Just 3</h1>
                  <h2 class="text-white">Years</h2>
                  <h5 class="text-white mb-0">Journey</h5>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
            <div class="h-100">
              <h1 class="display-6 mb-5">
                আমরা শুরু করতে চাই ধৈর্য্য  ও সময় নিয়ে আর এগিয়ে যেতে চাই লক্ষের দিকে
              </h1>
              <p class="fs-5 text-primary mb-4">
                সময়ত মানুষের চলেই যায়, আর চলে যাওয়ার ফাকে ফাকে কিছু সঞ্চয় করতে পারলে এক সময় তা লক্ষ পূরণের মূলধন হয়ে দাড়ায়। ‍আপনার আজকের ক্ষুদ্র ক্ষুদ্র সঞ্চয়ই আপনাকে প্রতিষ্ঠিত করার বৃহত্তর প্রচেষ্ঠা।
              </p>
              <p class="mb-4">
                 কথায় আছে আজকের সঞ্চয় আগামী দিনের ভবিষ্যৎ। সুতরাং আজকের সঞ্চয় দ্বারা আগামী দিনের ভবিষ্যৎ কে সুন্দরভাবে গড়ে তোলার জন্য আমাদের আজকের সঞ্চয় করা প্রয়োজন। আহরণ আমাদের সবার জীবনে একটি গুরুত্বপূর্ণ ভূমিকা পালন করে থাকে। তাই সঞ্চয় হতে পারে অর্থ-সম্পদ বা জ্ঞান। পৃথিবীতে সঞ্চয়ী ব্যক্তিরা জীবনে সফলতা অর্জন করতে পারে। আজকের উন্নত বিশ্ব গঠনে পিছনে সঞ্চয়ের অবদান বেশি। যে যে জাতি যত বেশি সঞ্চয় সে জাতি তত বেশি উন্নত।
              </p>
              <!-----<div class="border-top mt-4 pt-4">
                <div class="d-flex align-items-center">
                  <img
                    class="flex-shrink-0 rounded-circle me-3"
                    src="img/profile.jpg"
                    alt=""
                  />
                  <h5 class="mb-0">Call Us: +012 345 6789</h5>
                </div>
              </div>----->
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- About End -->

    <!-- Facts Start -->
    <div class="container-fluid overflow-hidden my-5 px-lg-0">
      <div class="container facts px-lg-0">
        <div class="row g-0 mx-lg-0">
          <div class="col-lg-6 facts-text wow fadeIn" data-wow-delay="0.1s">
            <div class="h-100 px-4 ps-lg-0">
              <h1 class="text-white mb-4">আমাদের প্রিয় বন্ধুদের নিয়ে একতার যাত্রা ও সফলতা</h1>
              <p class="text-light mb-5">
                ফ্রেন্ডস ফান্ড ফ্যামিলি আমাদের প্রিয় বন্ধুদের নিয়ে একতা ও ঐক্যের মিলন মেলা হিসেবে গড়ে তুলা ও সম্মিলিত প্রচেষ্টায় বড় ব্যবসার উদ্যোগ নিয়েই  যাত্রা শুরু।
              </p>
              <a href="#" class="align-self-start btn btn-secondary py-3 px-5"
                >বিস্তারিত জানতে >></a
              >
            </div>
          </div>
          <div class="col-lg-6 facts-counter wow fadeIn" data-wow-delay="0.5s">
            <div class="h-100 px-4 pe-lg-0">
              <div class="row g-5">
                <div class="col-sm-6">
                  <h1 class="display-5" data-toggle="counter-up">1234</h1>
                  <p class="fs-5 text-primary">Happy Member</p>
                </div>
                <div class="col-sm-6">
                  <h1 class="display-5" data-toggle="counter-up">1860</h1>
                  <p class="fs-5 text-primary">Runing Member</p>
                </div>
                <div class="col-sm-6">
                  <h1 class="display-5" data-toggle="counter-up">2400</h1>
                  <p class="fs-5 text-primary">Total Member</p>
                </div>
                <div class="col-sm-6">
                  <h1 class="display-5" data-toggle="counter-up">80</h1>
                  <p class="fs-5 text-primary">Total Share</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Facts End -->

    <!-- Features Start -->
    <div class="container-xxl py-5">
      <div class="container">
        <div class="row g-5">
          <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
            <h1 class="display-6 mb-5">আপনিও পারেন আমাদের সাথে এ্রক হয়ে পথ চলতে! </h1>
            <p class="mb-4">
              যদি একই লক্ষ আপনার ভিতর থাকে তাহলে আমাদের প্রিয় বন্ধুদের পাশাপাশি আপনিও আমাদের সাথে এ্রক হয়ে পথ চলতে পারেন। এখানে টাকা ফিরত গ্যারান্টি ১০০% , আছে ডিজিটাল সিস্টেমে পরিচালনা কমিটি। বন্ধুত্বের বন্ধনে,সঞ্চয় হোক কল্যানে।
            </p>
            <div class="row g-3">
              <div class="col-sm-6 wow fadeIn" data-wow-delay="0.1s">
                <div class="bg-light rounded h-100 p-3">
                  <div
                    class="bg-white d-flex flex-column justify-content-center text-center rounded h-100 py-4 px-3"
                  >
                    <img
                      class="align-self-center mb-3"
                      src="{{asset('backend_assets/LandingPage/img/icon/icon-06-primary.png')}}"
                      alt=""
                    />
                    <h5 class="mb-0">সহজ প্রক্রিয়ায রেজিস্ট্রেশন</h5>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 wow fadeIn" data-wow-delay="0.2s">
                <div class="bg-light rounded h-100 p-3">
                  <div
                    class="bg-white d-flex flex-column justify-content-center text-center rounded py-4 px-3"
                  >
                    <img
                      class="align-self-center mb-3"
                      src="{{asset('backend_assets/LandingPage/img/icon/icon-03-primary.png')}}"
                      alt=""
                    />
                    <h5 class="mb-0">অনলাইন কন্ট্রোল ও পেমেন্ট</h5>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 wow fadeIn" data-wow-delay="0.3s">
                <div class="bg-light rounded h-100 p-3">
                  <div
                    class="bg-white d-flex flex-column justify-content-center text-center rounded py-4 px-3"
                  >
                    <img
                      class="align-self-center mb-3"
                      src="{{asset('backend_assets/LandingPage/img/icon/icon-04-primary.png')}}"
                      alt=""
                    />
                    <h5 class="mb-0">স্ট্রং  চুক্তি পত্র</h5>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 wow fadeIn" data-wow-delay="0.4s">
                <div class="bg-light rounded h-100 p-3">
                  <div
                    class="bg-white d-flex flex-column justify-content-center text-center rounded h-100 py-4 px-3"
                  >
                    <img
                      class="align-self-center mb-3"
                      src="{{asset('backend_assets/LandingPage/img/icon/icon-07-primary.png')}}"
                      alt=""
                    />
                    <h5 class="mb-0">১০০% হালাল মাধ্যম ফলো করা</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
            <div
              class="position-relative rounded overflow-hidden h-100"
              style="min-height: 400px"
            >
              <img
                class="position-absolute w-100 h-100"
                src="{{asset('backend_assets/LandingPage/img/feature.jpg')}}"
                alt=""
                style="object-fit: cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Features End -->

    <!-- Service Start -->
    <!-- Service Start 
    <div class="container-xxl py-5">
      <div class="container">
        <div class="text-center mx-auto" style="max-width: 500px">
          <h1 class="display-6 mb-5">
            We Provide professional Insurance Services
          </h1>
        </div>
        <div class="row g-4 justify-content-center">
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
            <div class="service-item rounded h-100 p-5">
              <div class="d-flex align-items-center ms-n5 mb-4">
                <div
                  class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                >
                  <img
                    class="img-fluid"
                    src="img/icon/icon-10-light.png"
                    alt=""
                  />
                </div>
                <h4 class="mb-0">Life Insurance</h4>
              </div>
              <p class="mb-4">
                Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                sit clita duo justo erat amet
              </p>
              <a class="btn btn-light px-3" href="">Read More</a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
            <div class="service-item rounded h-100 p-5">
              <div class="d-flex align-items-center ms-n5 mb-4">
                <div
                  class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                >
                  <img
                    class="img-fluid"
                    src="img/icon/icon-01-light.png"
                    alt=""
                  />
                </div>
                <h4 class="mb-0">Health Insurance</h4>
              </div>
              <p class="mb-4">
                Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                sit clita duo justo erat amet
              </p>
              <a class="btn btn-light px-3" href="">Read More</a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
            <div class="service-item rounded h-100 p-5">
              <div class="d-flex align-items-center ms-n5 mb-4">
                <div
                  class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                >
                  <img
                    class="img-fluid"
                    src="img/icon/icon-05-light.png"
                    alt=""
                  />
                </div>
                <h4 class="mb-0">Home Insurance</h4>
              </div>
              <p class="mb-4">
                Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                sit clita duo justo erat amet
              </p>
              <a class="btn btn-light px-3" href="">Read More</a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
            <div class="service-item rounded h-100 p-5">
              <div class="d-flex align-items-center ms-n5 mb-4">
                <div
                  class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                >
                  <img
                    class="img-fluid"
                    src="img/icon/icon-08-light.png"
                    alt=""
                  />
                </div>
                <h4 class="mb-0">Vehicle Insurance</h4>
              </div>
              <p class="mb-4">
                Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                sit clita duo justo erat amet
              </p>
              <a class="btn btn-light px-3" href="">Read More</a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
            <div class="service-item rounded h-100 p-5">
              <div class="d-flex align-items-center ms-n5 mb-4">
                <div
                  class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                >
                  <img
                    class="img-fluid"
                    src="img/icon/icon-07-light.png"
                    alt=""
                  />
                </div>
                <h4 class="mb-0">Business Insurance</h4>
              </div>
              <p class="mb-4">
                Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                sit clita duo justo erat amet
              </p>
              <a class="btn btn-light px-3" href="">Read More</a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
            <div class="service-item rounded h-100 p-5">
              <div class="d-flex align-items-center ms-n5 mb-4">
                <div
                  class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                >
                  <img
                    class="img-fluid"
                    src="img/icon/icon-06-light.png"
                    alt=""
                  />
                </div>
                <h4 class="mb-0">Property Insurance</h4>
              </div>
              <p class="mb-4">
                Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                sit clita duo justo erat amet
              </p>
              <a class="btn btn-light px-3" href="">Read More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    Service End -->
    <!-- Service End -->

    <!-- Appointment Start -->
    <div
      class="container-fluid appointment my-5 py-5 wow fadeIn"
      data-wow-delay="0.1s"
    >
      <div class="container py-5">
        <div class="row g-5">
          <div class="col-lg-6 wow fadeIn" data-wow-delay="0.3s">
            <h1 class="display-6 text-white mb-5">
              আসুন আজকের দিনটাকে আমরা সঞ্চয় করি যাতে আমাদের সন্তানেরা কালকের দিনটাকে উপভোগ করতে পারে৷
            </h1>
            <p class="text-white">
              “ভবিষ্যতের ভাবনা ভাবাই জ্ঞানীর লক্ষণ” আল্লাহ বলেছেন- “আমি ততক্ষণ পর্যন্ত কোন জাতির ভাগ্যের পরিবর্তন করি না, যতক্ষণ পর্যন্ত না সে নিজে চেষ্টা করে।”
              আজকে আমরা যে বিষয়টি নিয়ে আলোচনা করছি- তা হলো সঞ্চয় ছোট বেলার একটি কবিতা মনে পড়ে যায়- মৌমাছি, মৌমাছি কোথায় যাও নাচি নাচি, দাঁড়াও না একবার ভাই, ঐ ফুল ফোটে বনে যাই মধু আহরণে দাড়াঁবার সময়তো নাই।
            </p>
            <p class="text-white">
              কবিতাটিতে কবি কত সুন্দর এবং সাবলীলভাবে আমাদের উপার্জন ও সঞ্চয়ের প্রতি গুরুত্ব দিয়েছেন একবার ভাবুনতো। এখন আমরা জানতে- চেষ্টা করি সঞ্চয় কি এবং কেন সঞ্চয় প্রয়োজন?- 
            </p>
            <p class="text-white">
              সঞ্চয় হচ্ছে আপনার আমার ক্রান্তিকালীন মূহুর্তের বন্ধু। আমরা জীবনে কখনও কোন বিপদের সম্মুখীন হব না এটা ভাবার কোন অবকাশ নেই।
            </p>
          </div>
          <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
            <div class="bg-white rounded p-5">
              <form>
                <div class="row g-3">
                  <div class="col-sm-6">
                    <div class="form-floating">
                      <input
                        type="text"
                        class="form-control"
                        id="gname"
                        placeholder="Gurdian Name"
                      />
                      <label for="gname">Your Name</label>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-floating">
                      <input
                        type="email"
                        class="form-control"
                        id="gmail"
                        placeholder="Gurdian Email"
                      />
                      <label for="gmail">Your Email</label>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-floating">
                      <input
                        type="text"
                        class="form-control"
                        id="cname"
                        placeholder="Child Name"
                      />
                      <label for="cname">Your Mobile</label>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-floating">
                      <input
                        type="text"
                        class="form-control"
                        id="cage"
                        placeholder="Child Age"
                      />
                      <label for="cage">Service Type</label>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="form-floating">
                      <textarea
                        class="form-control"
                        placeholder="Leave a message here"
                        id="message"
                        style="height: 80px"
                      ></textarea>
                      <label for="message">Message</label>
                    </div>
                  </div>
                  <div class="col-12">
                    <button class="btn btn-primary py-3 px-5" type="submit">
                      Get Appointment
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Appointment End -->

    <!-- Team Start -->
    <div class="container-xxl py-5">
      <div class="container">
        <div class="text-center mx-auto" style="max-width: 500px">
          <h1 class="display-6 mb-5"> আমাদের "F F F"  প্রিয় সদস্য গণ</h1>
        </div>
        <div class="row g-4">
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/2.png')}}" alt="" />
              <div class="text-center p-4">
                <h5>মাসুম বিল্লাহ</h5>
                <span>জেল ডিফেন্স</span>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5>মাসুম বিল্লাহ</h5>
                <span>জেল ডিফেন্স</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/1.png')}}" alt="" />
              <div class="text-center p-4">
                <h5> ইসমাইল হোসেন</h5>
                <span>প্রবাসী</span>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5> ইসমাইল হোসেন</h5>
                <span>প্রবাসী</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/3.png')}}" alt="" />
              <div class="text-center p-4">
                <h5>মো: শাহজালাল</h5>
                <span>প্রবাসী</span>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5>মো: শাহজালাল</h5>
                <span>প্রবাসী</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/4.png')}}" alt="" />
              <div class="text-center p-4">
                <h5>সাইফুল ইসলাম সাওন</h5>
                <span>প্রবাসী</span>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5>সাইফুল ইসলাম সাওন</h5>
                <span>প্রবাসী</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row g-4">
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/5.png')}}" alt="" />
              <div class="text-center p-4">
                <h5>আব্দুর রহমান</h5>
                <span>ব্যবসায়ী</span>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5>আব্দুর রহমান</h5>
                <span>ব্যবসায়ী</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/6.png')}}" alt="" />
              <div class="text-center p-4">
                <h5>রমজান আলী ইমন</h5>
                <span>সোসাইল ওয়ারকার</span>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5>রমজান আলী ইমন</h5>
                <span>সোসাইল ওয়ারকার</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/7.png')}}" alt="" />
              <div class="text-center p-4">
                <h5> মো: সুজন</h5>
                <span>প্রবাসী</span>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5> মো: সুজন</h5>
                <span>প্রবাসী</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
            <div class="team-item rounded">
              <img class="img-fluid" src="{{asset('backend_assets/LandingPage/img/8.jpeg')}}" alt="" />
              <div class="text-center p-4">
               <h5>মিলিয়ন মামুন</h5>
                <span>প্রবাসী</spann>
              </div>
              <div class="team-text text-center bg-white p-4">
                <h5>মিলিয়ন মামুন</h5>
                <span>প্রবাসী</span>
                <div class="d-flex justify-content-center">
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-twitter"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-facebook-f"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-youtube"></i
                  ></a>
                  <a class="btn btn-square btn-light m-1" href=""
                    ><i class="fab fa-linkedin-in"></i
                  ></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Team End -->

    <!-- Testimonial Start -->
    <div class="container-xxl py-5">
      <div class="container">
        <div class="text-center mx-auto" style="max-width: 500px">
          <h1 class="display-6 mb-5">ফ্রেন্ডস ফান্ড ফ্যামিলি সমপর্কে আমাদের সদস্যদের মন্তব্য</h1>
        </div>
        <div class="row g-5">
          <div class="col-lg-3 d-none d-lg-block">
            <div class="testimonial-left h-100">
              <img
                class="img-fluid animated pulse infinite"
                src="{{asset('backend_assets/LandingPage/img/1.png')}}"
                alt=""
              />
              <img
                class="img-fluid animated pulse infinite"
                src="{{asset('backend_assets/LandingPage/img/2.png')}}"
                alt=""
              />
              <img
                class="img-fluid animated pulse infinite"
                src="{{asset('backend_assets/LandingPage/img/3.png')}}"
                alt=""
              />
            </div>
          </div>
          <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
            <div class="owl-carousel testimonial-carousel">
              <div class="testimonial-item text-center">
                <img
                  class="img-fluid rounded mx-auto mb-4"
                  src="{{asset('backend_assets/LandingPage/img/3.png')}}"
                  alt=""
                />
                <p class="fs-5">
                  সঞ্চয় প্রতিটি মানুষের প্রয়োজন আর প্রয়োজনের তাগিদেই  ফ্রেন্ডস ফান্ড ফ্যামিলিতে আসা, ইনশাল্লাহ এক সাথে চলতে চাই এই সমিতির সাথে
                </p>
                <h5>মো: শাহজালাল</h5>
                <span>প্রবাসী</span>
              </div>
              <div class="testimonial-item text-center">
                <img
                  class="img-fluid rounded mx-auto mb-4"
                  src="{{asset('backend_assets/LandingPage/img/5.png')}}"
                  alt=""
                />
                <p class="fs-5">
                  ভালবাসার আরেক নাম ফ্রেন্ডস ফান্ড ফ্যামিলি, আশা করি এভাবেই তারা তাদের সেবার মাধ্যমে সকল সদস্যদের  ভালোবাসা ধরে রাখবে আজীবন
                </p>
                <h5>আব্দুর রহমান</h5>
                <span>ব্যবসায়ী</span>
              </div>
              <div class="testimonial-item text-center">
                <img
                  class="img-fluid rounded mx-auto mb-4"
                  src="{{asset('backend_assets/LandingPage/img/6.png')}}"
                  alt=""
                />
                <p class="fs-5">
                  আসলে ফ্রেন্ডস ফান্ড ফ্যামিলি যে উদ্দ্যোগ  নিয়েছে তা আমার অনেক আগেই এ ধরনের একটা প্লাটফ্রম করার চিন্তা আমার ছিল,কিন্তু সবাইকে এক সাথে মিল করে কারাটা হয়ে উঠছিল না, কিন্তু যখন দেখলাম ফ্রেন্ডস ফান্ড ফ্যামিলি  এটার উদ্দ্যোগ নিয়েছে তখন আর দেরি না করে জয়েন করে নিলাম
                </p>
                <h5>রমজান আলী ইমন</h5>
                <span>সোসাইল ওয়ারকার</span>
              </div>
            </div>
          </div>
          <div class="col-lg-3 d-none d-lg-block">
            <div class="testimonial-right h-100">
              <img
                class="img-fluid animated pulse infinite"
                src="{{asset('backend_assets/LandingPage/img/4.png')}}"
                alt=""
              />
              <img
                class="img-fluid animated pulse infinite"
                src="{{asset('backend_assets/LandingPage/img/5.png')}}"
                alt=""
              />
              <img
                class="img-fluid animated pulse infinite"
                src="{{asset('backend_assets/LandingPage/img/6.png')}}"
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Testimonial End -->
@endsection