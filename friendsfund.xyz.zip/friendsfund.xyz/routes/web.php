<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'landingPageCon@homepage');
Route::get('/ourmember', 'landingPageCon@ourMember');
//Auth::routes();
Auth::routes(['register' => false]);

Route::group(['middleware'=>['admin','auth'],], function(){
Route::get('/home', 'adminDeshboardCon@view')->name('home');

    Route::get('/addMember', 'memberAddCon@addMember');
    Route::post('/addMember', 'memberAddCon@addstore');
    Route::get('/memberList', 'memberAddCon@memberView');
    Route::get('/memberview/{id}', 'memberAddCon@memberSingleView');
    Route::get('/buyerMemberList', 'memberAddCon@buyerMemberView');
    Route::get('/byermemberview/{id}', 'memberAddCon@buyermemberSingleView');

      //Share-------------------------------
    Route::get('/addShare', 'shareCon@addShare');
    Route::post('/addShare', 'shareCon@shareStore');
    Route::get('/buyshare', 'shareCon@buyShare');
    Route::post('/buyshare', 'shareCon@buyshareStore');
    Route::get('/shareList', 'shareCon@shareList');

    //invest----------------------------
    Route::get('/addInvest', 'investCon@addInvest');
    Route::post('/addInvest', 'investCon@investStore');
    Route::get('/investList', 'investCon@investList');

    //investProfit--------------------
    Route::get('/addInvestProfit', 'investProfitCon@addInvestProfit');
    Route::post('/addInvestProfit', 'investProfitCon@investProfitStore');
    Route::get('/profitInvestList', 'investProfitCon@profitInvestList');
    Route::get('/investSelect/{id}', 'investProfitCon@selectInvest');

//monthDeposit------------------------
    Route::get('/CrMonthDepositList', 'monthDepositCon@CrMonthDepositList');
    Route::get('/monthDepositList/{id}', 'monthDepositCon@monthDepositList');
    Route::get('/addmonthDeposit', 'monthDepositCon@addMonthDeposit');
    Route::get('/addmonthSelect/{id}', 'monthDepositCon@addmonthSelect');
    Route::get('/searchMemberdeposit', 'monthDepositCon@searchMemberCreate');
    Route::post('/checkMemberdeposit', 'monthDepositCon@checkMemberdeposit');
    Route::get('/createInvoic_month/{id}', 'monthDepositCon@monthCreateInvoice');
    Route::post('/createInvoic_month', 'monthDepositCon@monthCreateInvoiceStor');
    Route::get('/monthDepositListSingleView/{id}', 'monthDepositCon@monthDepositListView');

    //month Pay------------------------------------
    Route::get('/payment_create/{id}', 'payController@create');
    Route::get('/payment_vawser/{id}', 'payController@vawcer');
    Route::post('/pay_submit/', 'payController@pay_stor');
});
    //Member deshbord
    //Member Login
    
    Route::get('member_login','memberLogCon@memreate');
    Route::post('member/check','memberLogCon@check');
    //Member deshbord
Route::group(['middleware'=>'member'], function(){
    Route::get('/dashboardd', 'userDeshCon@view');
    Route::get('/userdetails/{id}','userDeshCon@userdetail');
    Route::get('/member/changePass','userDeshCon@changePass');
    Route::post('/member/changePassStor','userDeshCon@changePassStor');
    Route::get('member/logout','userDeshCon@logout');
});