<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invoice extends Model
{
     protected $fillable = [
        'share_id',
        'bill_id',
        'invoice_date',
        'added_by',
        'status',
    ];

    public function invoiceMember(){
        return $this->hasMany('App\memberInvoice','invoice_date_id','bill_id');
    }

    //due 
    public function invoiceMemberDue(){
        return $this->hasMany('App\memberInvoice','invoice_date_id','bill_id')->where('payment', 0);
    }

    public function shareSelect(){
        return $this->hasOne('App\createShare','id','share_id');
    }
}
