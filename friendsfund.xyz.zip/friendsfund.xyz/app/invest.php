<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invest extends Model
{
    
    protected $fillable = [
        'invest_name',
        'lonaner_name',
        'invest_amount',
        'lonan_expair_date',
        'profit_system',
        'Profit_amount',
        'about_invest_explain',
        'added_by',
        'status',
    ];
}
