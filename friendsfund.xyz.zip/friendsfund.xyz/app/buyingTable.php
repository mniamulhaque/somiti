<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Session;

class buyingTable extends Model
{
       protected $fillable = [
        'member_id',
        'share_id',
        'shareQuantity',
        'share_amount',
        'buying_date',
        'added_by',
        'status',
    ];


    public function sharePrice(){
        return $this->hasOne('App\createShare','id','share_id');
    }

    public function shareInvest(){
        return $this->hasMany('App\invest','share_id','share_id');
    }

    //Total Share
    public function totalShare(){
        return $this->hasMany('App\buyingTable','share_id','share_id');
    }

    //invest Profit
    public function InvestProfit(){
        return $this->hasMany('App\investProfit','share_id','share_id');
    }

    public function MemberInvoicee(){
        $userId =  Session::get('member_info')[0];
        return $this->hasMany('App\memberInvoice','share_id','share_id')->where('member_id',$userId);
    }
}
