<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class memberInvoice extends Model
{
    public function selectMember(){
        return $this->hasOne('App\memberAdd','id','member_id');
    }

    public function sharePrice(){
        return $this->hasOne('App\createShare','id','share_id');
    }

    public function buyingTable() {
    return $this->belongsTo('App\buyingTable','share_id','share_id');
}
}
