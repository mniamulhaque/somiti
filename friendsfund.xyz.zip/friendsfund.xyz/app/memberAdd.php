<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class memberAdd extends Model
{
    protected $fillable = [
        'name',
        'email',
        'password',
        'father_name',
        'addr',
        'nid',
        'gender',
        'dob',
        'mobile',
        'Alternative_number',
        'profesion',
        'upazila',
        'district',
        'Divi',
        'memberType',
        'photo',
        'nid_photo',
        'added_by',
        'status',
    ];

    public function selectBuying(){
        return $this->hasOne('App\buyingTable','member_id','id');
    }
}
