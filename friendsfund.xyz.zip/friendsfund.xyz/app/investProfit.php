<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class investProfit extends Model
{
     protected $fillable = [
        'share_id',
        'invest_id',
        'invest_name',
        'lonaner_name',
        'entre_date',
        'fixt_profit_amount',
        'Profit_amount',
        'profit_details',
        'added_by',
        'status',
    ];
}
