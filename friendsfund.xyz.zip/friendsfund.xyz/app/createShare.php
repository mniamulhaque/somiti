<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class createShare extends Model
{
     protected $fillable = [
        'Share_name',
        'share_amount',
        'share_limit',
        'share_expair_date',
        'about_share_explain',
        'share_photo',
        'added_by',
        'status',
    ];
}
