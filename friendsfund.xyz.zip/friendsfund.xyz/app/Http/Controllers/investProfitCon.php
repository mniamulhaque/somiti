<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\invest;
use App\investProfit;
use Validator;
use Session;
use DB;

class investProfitCon extends Controller
{
    public function addInvestProfit(){
        $investData = invest::all();
        return view('backend.pages.addInvestProfit',compact('investData'));
    }
    //select Ajax
    public function selectInvest($id)
    {

        $investData = DB::table('invests')->where('id', $id)->first();
        $investProfData = DB::table('invest_profits')->where('invest_id', $id)->get();
        $shareData = DB::table('create_shares')->where('id', $investData->share_id)->first();


                $profit_previous_due_count = $investProfData->where('Profit_amount', 0);
                $Total_profit_paid_qiantity_count = $investProfData->where('Profit_amount','>',0);

                $profit_previous_due = count($profit_previous_due_count);
                $Total_profit_paid_qiantity = count($Total_profit_paid_qiantity_count);
                    $response = [
                        'share_id' => $investData->share_id,
                        'share_name' => $shareData->Share_name,
                        'invest_name' => $investData->invest_name,
                        'lonaner_name' => $investData->lonaner_name,
                        'invest_amount' => $investData->invest_amount,
                        'lonan_expair_date' => $investData->lonan_expair_date,
                        'profit_system' => $investData->profit_system,
                        'profit_previous_due' => $profit_previous_due,
                        'Total_profit_paid_qiantity' => $Total_profit_paid_qiantity,
                        'fixt_profit_amount' => $investData->Profit_amount,
                        ];
                    echo json_encode($response);
    }


    public function investProfitStore(Request $request)
    {
        $investProfitData = new investProfit;

         $validator = validator::make($request->all(),[
            'invest_id'=>'required',
            'lonaner_name'=>'required',
            'Profit_amount'=>'required',
            'entre_date'=>'required',
        ]);

        if($validator->fails()){
            return redirect('/addInvestProfit')->withErrors($validator)->withInput();
        }

        if($request->profit_details == null){
            $profit_details = 0;
        }else{
           $profit_details = $request->profit_details;
        }

        $investProfitData->share_id = $request->share_id;
        $investProfitData->share_name = $request->share_name;
        $investProfitData->invest_id = $request->invest_id;
        $investProfitData->invest_name = $request->invest_name;
        $investProfitData->lonaner_name = $request->lonaner_name;
        $investProfitData->entre_date = $request->entre_date;
        $investProfitData->fixt_profit_amount = $request->fixt_profit_amount;
        $investProfitData->Profit_amount = $request->Profit_amount;
        $investProfitData->profit_details = $profit_details;
        $investProfitData->added_by = "Admin";
        $investProfitData->status = 1;
        $investProfitData->save(); 

       
        Session::flash('message','Profit Deposit Successfully');
        
        return redirect('/addInvestProfit');
    }

  public function profitInvestList(){
        $investProfitData = investProfit::where('status',1)->get();
        return view('backend.pages.investProfitList',compact('investProfitData'));
    }
}
