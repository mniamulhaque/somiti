<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Validator;
use Illuminate\Support\Facades\Hash;
use App\memberAdd;
use App\memberInvoice;
use Session;
use DB;

class memberAddCon extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

   public function addMember(){

        $centerTotalStu = count(memberAdd::all());
        if($centerTotalStu > 0){
          $stid = memberAdd::latest()->first()->id;  
      }else{
        $stid = 0;
      }
        
        
        $stidd = $stid+1;
        $rollno = rand(1000,10000).$stidd;
        return view('backend.pages.addMember',compact('rollno'));
    }

     public function addstore(Request $request)
    {
        if($request->email == null){
            $email = 0;
        }else{
            $email = $request->email;
        }
        $validator = validator::make($request->all(),[
            'member_id' =>'required|unique:member_adds',
            'name'=>'required',
            'password' =>'required',
            'father_name' =>'required',
            'addr' =>'required',
            'nid' =>'required',
            'gender'=>'required',
            'dob' =>'required',
            'mobile' =>'required|min:10|unique:member_adds',
            'Alternative_number' =>'required',
            'profesion' =>'required',
            'upazila' =>'required',
            'district' =>'required',
            'Divi' =>'required',
            'nominiName' =>'required',
            'nominiSomorko' =>'required',
            'photo' =>'image|mimes:jpg,jpeg,png,gif|max:100',
            'nid_photo' =>'image|mimes:jpg,jpeg,png,gif|max:100',
            'NominiPhoto' =>'image|mimes:jpg,jpeg,png,gif|max:100',
            'NominiNid_photo' =>'image|mimes:jpg,jpeg,png,gif|max:100',
        ]);

        if($validator->fails()){
            return redirect('/addMember')->withErrors($validator)->withInput();
        }

        $filePhoto = null;
        $filenid_photo = null;
        $fileNominiPhoto = null;
        $fileNominiNid_photo = null;
        if (request()->hasFile('photo')) {
                $photo = request()->file('photo');
                $filePhoto = md5($photo->getClientOriginalName() . time()) . "." . $photo->getClientOriginalExtension();
                $filePatch = 'backend_assets/images/member';
                $photo->move($filePatch, $filePhoto);    
            }

        if (request()->hasFile('nid_photo')) {
                $nid_photo = request()->file('nid_photo');
                $filenid_photo = md5($nid_photo->getClientOriginalName() . time()) . "." . $nid_photo->getClientOriginalExtension();
                $filePatch = 'backend_assets/images/member';
                $nid_photo->move($filePatch, $filenid_photo);    
            }

        if (request()->hasFile('NominiPhoto')) {
                $NominiPhoto = request()->file('NominiPhoto');
                $fileNominiPhoto = md5($NominiPhoto->getClientOriginalName() . time()) . "." . $NominiPhoto->getClientOriginalExtension();
                $filePatch = 'backend_assets/images/member';
                $NominiPhoto->move($filePatch, $fileNominiPhoto);    
            }

        if (request()->hasFile('NominiNid_photo')) {
                $NominiNid_photo = request()->file('NominiNid_photo');
                $fileNominiNid_photo = md5($NominiNid_photo->getClientOriginalName() . time()) . "." . $NominiNid_photo->getClientOriginalExtension();
                $filePatch = 'backend_assets/images/member';
                $NominiNid_photo->move($filePatch, $fileNominiNid_photo);    
            }

        $memberAddData = new memberAdd;

        
            $memberAddData->member_id = $request->member_id;
            $memberAddData->name = $request->name;
            $memberAddData->email = $email;
            $memberAddData->password = Hash::make($request->password);
            $memberAddData->father_name = $request->father_name;
            $memberAddData->addr = $request->addr;
            $memberAddData->nid = $request->nid;
            $memberAddData->gender = $request->gender;
            $memberAddData->dob = $request->dob;
            $memberAddData->mobile = $request->mobile;
            $memberAddData->Alternative_number = $request->Alternative_number;
            $memberAddData->profesion = $request->profesion;
            $memberAddData->upazila = $request->upazila;
            $memberAddData->district = $request->district;
            $memberAddData->Divi = $request->Divi;
            $memberAddData->nominiName = $request->nominiName;
            $memberAddData->nominiSomorko = $request->nominiSomorko;
            $memberAddData->NominiPhoto = $fileNominiPhoto;
            $memberAddData->NominiNid_photo = $fileNominiNid_photo;
            $memberAddData->memberType = '0';
            $memberAddData->shareId = '0';
            $memberAddData->photo = $filePhoto;
            $memberAddData->nid_photo = $filenid_photo;
            $memberAddData->added_by = 'Vocs';
            $memberAddData->status = 1;
            $memberAddData->save();
        
        Session::flash('message','Member Add Successfully');
        
        return redirect('/addMember');

    }

   

  public function memberView(){
        $memberViewOne = 1;
        $userData =  memberAdd::all();
        return view('backend.pages.memberList',compact('userData','memberViewOne'));
    }

    public function buyerMemberView(){
        $memberViewOne = 2;
        $userData = DB::table('buying_tables')->join('member_adds','buying_tables.member_id','member_adds.id')->where('member_adds.status',1)->select('name','father_name','mobile','Alternative_number','addr','buying_tables.*')->get();
        //dd($userData);
        return view('backend.pages.shareBuyerList',compact('userData','memberViewOne'));
    }


    public function memberSingleView($id){
        $userData =  memberAdd::find($id);
        return view('backend.pages.memberSingleView',compact('userData'));
    }

    public function buyermemberSingleView($id){
        $userData = DB::table('buying_tables')->join('member_adds','buying_tables.member_id','member_adds.id')->where('member_adds.status',1)->where('buying_tables.id',$id)->select('share_id','share_amount','shareQuantity','buying_date','member_adds.*')->first();
        $memberInvoiceData =  memberInvoice::where('member_id',$userData->id)->where('share_id',$userData->share_id)->get();
        //dd(count($memberInvoiceData));
        return view('backend.pages.buyermemberSingleView',compact('userData','memberInvoiceData'));
    }
}
