<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\invoice;
use App\createShare;
use App\memberInvoice;
use App\buyingTable;
use App\memberAdd;
use Validator;
use Session;
use DB;

class monthDepositCon extends Controller
{
    public function CrMonthDepositList(){
        $Share = createShare::all();
        return view('backend.pages.createMonthDepo',compact('Share'));
    }

    public function monthDepositList($id){
        $share_id = $id;
        $invoic = invoice::where('share_id',$id)->get();
        return view('backend.pages.monthDepositList',compact('invoic','share_id'));
    }

    public function monthCreateInvoice($id){
        $share_id = $id;
        $invoic = invoice::all();
        if(count($invoic) == 0){
            $invoiceid = 0;
        }else{
          $invoiceid = invoice::latest()->first()->id;  
        }
        
        $invoice_Codate = date("dmy").$invoiceid+1;
        return view('backend.pages.createMonthInvoice',compact('invoice_Codate','share_id'));
    }

    public function monthCreateInvoiceStor(Request $request)
    {
        $meberData = DB::table('buying_tables')->join('member_adds','buying_tables.member_id','member_adds.id')->where('member_adds.status',1)->where('buying_tables.share_id',$request->share_id)->get();
         $invoiceData = new invoice;

         $validator = validator::make($request->all(),[
            'share_id'=>'required',
            'bill_id'=>'required|unique:invoices',
            'invoice_date'=>'required',

        ]);
         $checkinvoice = invoice::where('share_id',$request->share_id)->where('invoice_date',$request->invoice_date)->first();
        if($validator->fails()){
            return redirect('/createInvoic_month/'.$request->share_id)->withErrors($validator)->withInput();
        }elseif($checkinvoice != null){
            Session::flash('error','This Month Already Taken');
             return redirect('/createInvoic_month/'.$request->share_id);
        }

        $invoiceData->bill_id = $request->bill_id;
        $invoiceData->share_id = $request->share_id;
        $invoiceData->invoice_date = $request->invoice_date;
        $invoiceData->added_by = "admin";
        $invoiceData->status = 0;
        

        foreach ($meberData as $value) {
            $buyingTableData = buyingTable::where('member_id',$value->id)->where('share_id',$request->share_id)->first();
            $memberInvoicData = new memberInvoice;
            $memberInvoicData->invoice_date_id = $request->bill_id;
            $memberInvoicData->invoice_date = $request->invoice_date;
            $memberInvoicData->member_id = $value->id;
            $memberInvoicData->share_id = $buyingTableData->share_id;
            $memberInvoicData->share_amount = $buyingTableData->share_amount;
            $memberInvoicData->payment = 0;
            $memberInvoicData->pay_date = 0;
            $memberInvoicData->added_by_month = 0;
            $memberInvoicData->added_by = "admin";
            $memberInvoicData->active = 0;
            $memberInvoicData->save();
        }

        $invoiceData->save();

       
        Session::flash('message','Month Invoice Generate Successfully');
        
        return redirect('/monthDepositList/'.$request->share_id);
    }


    public function monthDepositListView($id){

        $invoicData = invoice::where('bill_id',$id)->first();
        $invoicMemberData = memberInvoice::where('invoice_date_id',$id)->where('share_id',$invoicData->share_id)->get();
        //for due member list
        $invoicMemberDueData = memberInvoice::where('invoice_date_id',$id)->where('share_id',$invoicData->share_id)->where('payment',0)->get();

        //for amount colect
        $customerpaidAmount = memberInvoice::where('added_by_month',$invoicData->invoice_date)->where('share_id',$invoicData->share_id)->where('payment','!=', 0)->get();
        //for due amount
        $invoicMemberpaidData = memberInvoice::where('invoice_date_id',$id)->where('share_id',$invoicData->share_id)->where('payment','!=', 0)->get();

       return view('backend.pages.monthDepositListSingView',compact('invoicMemberData','invoicData','invoicMemberDueData','invoicMemberpaidData','customerpaidAmount'));
    }

    public function addMonthDeposit(){
        $createShare = createShare::all();
        return view('backend.pages.addmonthDepo',compact('createShare'));
    }

    public function addmonthSelect($id){
        $response = invoice::where('share_id',$id)->get();
        echo json_encode($response);
    }

    public function searchMemberCreate(){
        return view('backend.pages.searchMemberDeposit');
    }

    public function checkMemberdeposit(Request $request){
        $validator = validator::make($request->all(),[
            'memberNumber'=>'required',

        ]);
        $memberAdd = memberAdd::where('mobile',$request->memberNumber)->orWhere('member_id',$request->memberNumber)->first();
        if($validator->fails()){
            return redirect('/searchMemberdeposit')->withErrors($validator)->withInput();
        }elseif($memberAdd == null){
            Session::flash('error','Please Input Valid Number');
             return redirect('/searchMemberdeposit');
        }
        $invoicMemberData = memberInvoice::where('member_id',$memberAdd->id)->get();
        return view('backend.pages.checkMemberDeposit',compact('invoicMemberData'));
    }
}

