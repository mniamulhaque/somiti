<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\createShare;
use App\buyingTable;
use App\invoice;
use App\memberInvoice;
use App\memberAdd;
use Validator;
use Session;

class shareCon extends Controller
{
    public function addShare(){

        return view('backend.pages.addShare');
    }

    public function buyShare(){
        $ShareData = createShare::where('status',1)->get();
        $memberData = memberAdd::where('status',1)->get();
        return view('backend.pages.buyShare',compact('ShareData','memberData'));
    }

    public function buyshareStore(Request $request)
    {
        $buyingTableData = new buyingTable;

         $validator = validator::make($request->all(),[
            'member_id'=>'required',
            'share_id'=>'required',
            'shareQuantity'=>'required',
            'buying_date'=>'required',
        ]);

         $check_invoice = invoice::where('share_id',$request->share_id)->get();

         //dd(count($check_invoice));

         $checkbuyingTable = buyingTable::where('share_id',$request->share_id)->where('member_id',$request->member_id)->first();

        if($validator->fails()){
            return redirect('/buyshare')->withErrors($validator)->withInput();
        }elseif($checkbuyingTable != null){
            Session::flash('error','This Member Already Buy its share');
             return redirect('/buyshare');
        }

        $ShareData = createShare::where('id',$request->share_id)->first();
        $share_amount = $ShareData->share_amount * $request->shareQuantity;

        $buyingTableData->member_id = $request->member_id;
        $buyingTableData->share_id = $request->share_id;
        $buyingTableData->share_amount = $share_amount;
        $buyingTableData->shareQuantity = $request->shareQuantity;
        $buyingTableData->buying_date = $request->buying_date;
        $buyingTableData->added_by = "Admin";
        $buyingTableData->status = 1;
        if(count($check_invoice) > 0){

        foreach ($check_invoice as $value) {
            $memberInvoicData = new memberInvoice;
            $memberInvoicData->invoice_date_id = $value->bill_id;
            $memberInvoicData->invoice_date = $value->invoice_date;
            $memberInvoicData->member_id = $request->member_id;
            $memberInvoicData->share_id = $request->share_id;
            $memberInvoicData->share_amount = $share_amount;
            $memberInvoicData->payment = 0;
            $memberInvoicData->pay_date = 0;
            $memberInvoicData->added_by_month = 0;
            $memberInvoicData->added_by = "admin";
            $memberInvoicData->active = 0;
            $memberInvoicData->save();
        }

    }
        $buyingTableData->save(); 

       
        Session::flash('message','Share Create Successfully');
        
        return redirect('/buyshare');
    }

      public function shareStore(Request $request)
    {
        $createShareData = new createShare;

         $validator = validator::make($request->all(),[
            'Share_name'=>'required|unique:create_shares',
            'share_amount'=>'required',
            'share_expair_date'=>'required',
            'about_share_explain'=>'required',
            'share_photo'=>'image|mimes:jpg,jpeg,png,gif|max:100',
        ]);

        if($validator->fails()){
            return redirect('/addShare')->withErrors($validator)->withInput();
        }

        $file_photo = null;
        if (request()->hasFile('share_photo')) {
                $photo = request()->file('share_photo');
                $file_photo = md5($photo->getClientOriginalName() . time()) . "." . $photo->getClientOriginalExtension();
                $filePatch = public_path('backend_assets/images');
                $photo->move($filePatch, $file_photo);    
            }

        $createShareData->Share_name = $request->Share_name;
        $createShareData->share_amount = $request->share_amount;
        $createShareData->share_limit = $request->share_limit;
        $createShareData->share_expair_date = $request->share_expair_date;
        $createShareData->about_share_explain = $request->about_share_explain;
        $createShareData->share_photo = $file_photo;
        $createShareData->added_by = "Admin";
        $createShareData->status = 1;
        $createShareData->save(); 

       
        Session::flash('message','Share Create Successfully');
        
        return redirect('/addShare');
    }

  public function shareList(){

        $ShareData = createShare::where('status',1)->get();
        return view('backend.pages.shareList',compact('ShareData'));
    }
}
