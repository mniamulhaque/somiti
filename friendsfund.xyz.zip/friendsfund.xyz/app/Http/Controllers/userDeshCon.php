<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\createShare;
use App\buyingTable;
use App\memberInvoice;
use App\invest;
use App\investProfit;
use App\memberAdd;
use DB;
use Hash;
use Session;

class userDeshCon extends Controller
{
    public function view(){
        $userId =  Session::get('member_info')[0];
        $share = createShare::all();

        $shareBuying = buyingTable::where('status',1)->where('member_id',$userId)->get();
        $TotalshareBuying = buyingTable::where('status',1)->get();
        $invest = count(invest::where('status',1)->get());
        $memberInvoiceData = memberInvoice::where('member_id',$userId)->sum('payment');
        $investProfitData = investProfit::all()->sum('Profit_amount');
        $memberDue = DB::table('member_adds')->join('member_invoices','member_adds.id','member_invoices.member_id')->where('payment',0)->select('member_adds.id')->get();
        $memberDuedata= count($memberDue->unique());


        //dd();
        return view('backend.pages.userfolder.userfirstPage',compact('shareBuying','TotalshareBuying','invest','memberInvoiceData','investProfitData','memberDuedata'));
    }

    public function logout(){
        session()->forget('member_info');
        session()->flush();
        return redirect('member_login');
    }


     public function changePass(){

        return view('backend.pages.userfolder.changePass');
        

    }

    public function userdetail($id){
        $userId =  Session::get('member_info')[0];

        $shareBuying = buyingTable::where('status',1)->where('member_id',$userId)->where('share_id',$id)->first();
        $invoicMemberData = memberInvoice::where('member_id',$userId)->where('share_id',$id)->get();
        return view('backend.pages.userfolder.userDetails',compact('shareBuying','invoicMemberData'));
        

    }

     public function changePassStor(Request $request){

        $id = Session::get('member_info')[0];

        $member_info = Session::get('member_info');
        if ($member_info != null) {

        $request->validate([
          'current_password' => 'required',
          'password' => 'required|string|min:8|confirmed',
          'password_confirmation' => 'required',
        ]);

        $member = memberAdd::find($id);

        if (!Hash::check($request->current_password, $member->password)) {
           //dd('1');
             Session::flash('error', 'Current password does not match!');
              return redirect('/member/changePass');
        }else{
            //dd('2');
         $update = memberAdd::where('id',$id)->update([
            'password' => Hash::make($request->password),
        ]);

        Session::flash('message', 'Password successfully changed!');
        return redirect('/member_login');
        }

    }else{
        return redirect()->to('/member_login');
    }

    }
}
