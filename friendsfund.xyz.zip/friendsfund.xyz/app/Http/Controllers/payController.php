<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\invoice;
use App\createShare;
use App\memberInvoice;
use App\buyingTable;
use App\memberAdd;
use App\User;
use Validator;
use Session;
use DB;
class payController extends Controller
{
        public function create($id){
        $invoiceInfo = memberInvoice::find($id);
        $invoicMemberAllDue = memberInvoice::where('member_id',$invoiceInfo->member_id)->where('share_id',$invoiceInfo->share_id)->where('payment',0)->get();
        $invoicMemberAllDueSum = memberInvoice::where('member_id',$invoiceInfo->member_id)->where('share_id',$invoiceInfo->share_id)->where('payment',0)->sum('share_amount');
        $i = 0;
        return view('backend.pages.createPayment',compact('invoiceInfo','invoicMemberAllDue','i','invoicMemberAllDueSum','id'));
    }


     public function vawcer($id){
        $Todaydate = date('m-Y');
        $invoiceInfo = memberInvoice::find($id);
        $memverInfo = memberAdd::find($invoiceInfo->member_id);

         $pre_due1 = memberInvoice::where('member_id',$invoiceInfo->member_id)->where('payment',0)->where('invoice_date_id','!=',$invoiceInfo->invoice_date_id)->sum('share_amount');
         if ($pre_due1 == 0) {
             $pre_due = memberInvoice::where('member_id',$invoiceInfo->member_id)->where('pay_date','like','%'.$Todaydate.'%')->where('invoice_date_id','!=',$invoiceInfo->invoice_date_id)->sum('share_amount');
         }else{
            $pre_due = $pre_due1;
         }

        $invoicMemberAllDue1 = memberInvoice::where('member_id',$invoiceInfo->member_id)->where('share_id',$invoiceInfo->share_id)->where('payment',0)->get();
            if(count($invoicMemberAllDue1) == 0){
               $invoicMemberAllDue = memberInvoice::where('member_id',$invoiceInfo->member_id)->where('pay_date','like','%'.$Todaydate.'%')->get();
            }else{
               $invoicMemberAllDue = $invoicMemberAllDue1; 
            }
        $i = 0;
        return view('backend.pages.vawser',compact('invoiceInfo','invoicMemberAllDue','invoicMemberAllDue1','memverInfo','pre_due','pre_due1'));
        
    }
    //for vawcer pay submit
    public function vawcer_stor(Request $req){
        $line_rent = $req->line_rent;
        $line_id = $req->line_id;

        foreach($line_id as $key => $no)
        {
            $update = memberInvoice::where('id',$no)->update([
            'payment' => $line_rent[$key],
            'pay_date' => date('d-m-Y'),
            'added_by'  => 'Admin',
            'active' => '1'
        ]);

        }
        
        Session::flash('message', 'Update Successfully');
        return redirect()->back();
    }

    //for pay submit
    public function pay_stor(Request $req){
        $invMemId = memberInvoice::find($req->member_id);
        $line_rentData = $req->share_amountData;
        $line_rent = $req->share_amount;

        foreach($line_rentData as $key => $no)
        {
            $update = memberInvoice::where('id',$no)->update([
            'payment' => $line_rent[$key],
            'pay_date' => date('d-m-Y'),
            'added_by_month'  => $invMemId->invoice_date,
            'added_by'  => 'Admin',
            'active' => '1'
        ]);

           //dd($no);

        }
        
        Session::flash('message', 'Update Successfully');
        Session::put('payment_info',[$line_rentData,$line_rent]);
        return redirect('payment_vawser/'.$req->member_id);
    }
}
