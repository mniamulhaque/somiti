<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\createShare;
use App\buyingTable;
use App\memberInvoice;
use App\invest;
use App\investProfit;
use App\memberAdd;
use App\User;
use Illuminate\Support\Facades\Auth;
use DB;

class adminDeshboardCon extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function view(){
        
        $shareBuying = buyingTable::where('status',1)->get();
        $userData = memberAdd::all();
        $invest = count(invest::where('status',1)->get());
        $memberInvoiceData = memberInvoice::all()->sum('payment');
        $investProfitData = investProfit::all()->sum('Profit_amount');
        //$memberDue = DB::table('users')->join('member_invoices','users.id','member_invoices.member_id')->where('payment',0)->where('users.status','!=',701)->select('users.id')->get();
        //$memberDuedata= count($memberDue->unique());
        //dd();
        $memberDuedata= 0;
        return view('backend.index',compact('shareBuying','userData','memberInvoiceData','invest','investProfitData','memberDuedata'));  
        }


}