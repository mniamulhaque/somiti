<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\invest;
use App\createShare;
use Validator;
use Session;

class investCon extends Controller
{
    public function addInvest(){
        $ShareData = createShare::where('status',1)->get();
        return view('backend.pages.addInvest',compact('ShareData'));
    }

    public function investStore(Request $request)
    {
        $investData = new invest;

         $validator = validator::make($request->all(),[
            'share_id'=>'required',
            'lonaner_name'=>'required',
            'invest_amount'=>'required',
            'lonan_expair_date'=>'required',
            'profit_system'=>'required',
            'Profit_amount'=>'required',
            'about_invest_explain'=>'required',
        ]);

        if($validator->fails()){
            return redirect('/addInvest')->withErrors($validator)->withInput();
        }

        

        $investData->share_id = $request->share_id;
        $investData->invest_name = $sh_name->invest_name;
        $investData->lonaner_name = $request->lonaner_name;
        $investData->invest_amount = $request->invest_amount;
        $investData->lonan_expair_date = $request->lonan_expair_date;
        $investData->profit_system = $request->profit_system;
        $investData->Profit_amount = $request->Profit_amount;
        $investData->about_invest_explain = $request->about_invest_explain;
        $investData->added_by = "Admin";
        $investData->status = 1;
        $investData->save(); 

       
        Session::flash('message','Invest Create Successfully');
        
        return redirect('/addInvest');
    }

  public function investList(){
    $investData = invest::where('status',1)->get();
        return view('backend.pages.investList',compact('investData'));
    }
}

