<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class landingPageCon extends Controller
{
   
    public function homepage()
    {
        return view('/welcome');
    }

    public function ourMember()
    {
        return view('/teammember');
    }


}
