<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Session;
use Hash;
use DB;

class memberLogCon extends Controller
{
     public function memreate(){
        if (Session::get('member_info') != null) {
            return redirect('/dashboardd');
        }else{
        return view('backend.pages.userfolder.memberLogin');
     }
    }




   

    public function check(Request $request){
        //!Hash::check($request->password, $member->password)
        $password = Hash::make($request->password);
      $data = DB::table('member_adds')->where('mobile',$request->mobile)->first();

      //dd($data);
        

      if ($data != null && Hash::check($request->password, $data->password)) {
            if($data->status != 0){

                $id = $data->id;
                $member_id = $data->member_id;
                $name = $data->name;
                $MemberNumber = $data->mobile;
                $member_img = $data->photo;


                Session::put('member_info',[$id,$member_id,$name,$MemberNumber,$member_img]);
                return redirect('/dashboardd');
            }else{
               $err = "Sorry!! Your are Suspended. Please Contact your Frends fund Family Chairman";
            Session::flash('massage',$err);
                return redirect()->back(); 
            }

         
      }else{
         $err = "Your Number and password Not match!";
         Session::flash('massage',$err);
            return redirect()->back();
      }
    }
}
