<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\invest;
use DB;

class ajaxCon extends Controller
{
    public function selectInvest($id)
    {
        echo json_encode(DB::table('invests')->where('id', $id)->get());
    }
}
