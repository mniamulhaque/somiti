<?php

namespace App\Http\Middleware;

use Closure;
use Session;
class memberMiddle
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Session::get('member_info') != null){
           return $next($request); 
        }else{
            return redirect('/member_login');
        }
    }
}
