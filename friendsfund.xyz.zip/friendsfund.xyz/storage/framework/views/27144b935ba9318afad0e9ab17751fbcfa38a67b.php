
  <?php $__env->startSection('body'); ?>
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Deposit</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Collect</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Total Member</div>
                                            <div class="stat-digit gradient-3-text"><?php echo e(count($invoicMemberData)); ?></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-3" style="width: 50%;" role="progressbar"><span class="sr-only">50% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Due Member</div>
                                            <div class="stat-digit gradient-4-text"><?php echo e(count($invoicMemberDueData)); ?></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-4" style="width: 40%;" role="progressbar"><span class="sr-only">40% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">Paid Member</div>
                                            <div class="stat-digit gradient-4-text"> <?php echo e(count($invoicMemberData) - count($invoicMemberDueData)); ?></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-4" style="width: 15%;" role="progressbar"><span class="sr-only">15% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-content">
                                            <div class="stat-text">collected amount</div>
                                            <div class="stat-digit gradient-4-text"><i class="fa fa-usd"></i> <?php echo e($customerpaidAmount->sum('share_amount')); ?></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar gradient-4" style="width: 15%;" role="progressbar"><span class="sr-only">15% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><?php if(Session::has('message')): ?>
                                <div class="alert alert-success" role="alert">
                                  <?php echo e(Session::get('message')); ?>

                                </div>
                                <?php else: ?>
                                <?php echo e($invoicData->invoice_date); ?>

                                <?php endif; ?> Amount Collect</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Id</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Runing Month<br>Due</th>
                                                <th>Previous Months<br>Due</th>
                                                <th>Share Price</th>
                                                <th>Total Share</th>
                                                <th>Total Amount<br>Due</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <?php $__currentLoopData = $invoicMemberData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$MemInRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                             <?php
                                             if($MemInRow->payment == 0){
                                                $runingMo = $MemInRow->share_amount;
                                            }else{
                                                $runingMo = 0;
                                            }

                                            $memberPreDue = App\memberInvoice::where('member_id',$MemInRow->member_id)->where('payment',0)->where('share_id',$MemInRow->share_id)->where('invoice_date_id','!=',$MemInRow->invoice_date_id)->sum('share_amount');
                                            ?>
                                    <tr>
                                        <td><?php echo e($key++); ?></td>
                                        <td><?php echo e($MemInRow->invoice_date_id); ?></td>
                                        <td><?php echo e($MemInRow->selectMember->name); ?></td>
                                        <td><?php echo e($MemInRow->selectMember->mobile); ?></td>
                                        <td><?php echo e($runingMo); ?></td>
                                        <td id="loop"><?php echo e($memberPreDue); ?></td>
                                        <td><?php echo e($MemInRow->sharePrice->share_amount); ?></td>
                                        <td><?php echo e($MemInRow->share_amount / $MemInRow->sharePrice->share_amount); ?></td>
                                        <td>
                                            <?php echo e($memberPreDue+$runingMo); ?>

                                        </td>
                                        <td>
                                             <?php if($MemInRow->payment == 0): ?>
                                            <a href="<?php echo e(url('payment_create/'.$MemInRow->id)); ?>">Pay</a>
                                            <?php else: ?>
                                            Complated
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/monthDepositListSingView.blade.php ENDPATH**/ ?>