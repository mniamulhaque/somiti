
  <?php $__env->startSection('body'); ?>
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Table</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Name</th>
                                                <th>Share Price</th>
                                                <th>Share Limit</th>
                                                <th>Share Expair Date</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <?php $__currentLoopData = $ShareData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ShRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($ShRow->Share_name); ?></td>
                                                <td><?php echo e($ShRow->share_amount); ?></td>
                                                <td><?php echo e($ShRow->share_limit); ?></td>
                                                <td><?php echo e($ShRow->share_expair_date); ?></td>
                                                
                                                <td><a href="<?php echo e(url('/shareView/'.$ShRow->id)); ?>">View</a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/shareList.blade.php ENDPATH**/ ?>