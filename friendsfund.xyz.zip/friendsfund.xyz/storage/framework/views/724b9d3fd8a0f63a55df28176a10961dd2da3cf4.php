
  <?php $__env->startSection('body'); ?>
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Deposit</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Add Month Deposit</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Add Month Deposit</h4>
                                  <h4 class="card-title">
                                   <?php if($errors->has('bill_id')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('bill_id')); ?>

                                        </div>
                                    <?php elseif($errors->has('invoice_date')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('invoice_date')); ?>

                                        </div>
                                    <?php elseif(Session::has('message')): ?>
                                        <div class="alert alert-success" role="alert">
                                          <?php echo e(Session::get('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                 </h4>
                                <div class="basic-form">
                                    
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Select Share Nane</label>
                                                <select id="addmonthshare_id" name="addmonthshare_id" class="form-control">
                                                    <option value="">Choose Share...</option>
                                                    <?php $__currentLoopData = $createShare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($mRow->id); ?>"><?php echo e($mRow->Share_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Select Month</label>
                                                <select onchange="myFunc" id="invoice_date" name="invoice_date" class="form-control">
                                                    <option value="">Choose Month...</option>
                                                    <!-- <?php
                                                    $date = date_create($mRow->invoice_date);
                                                    $datee = date_format($date,"F - Y");
                                                    ?> -->
                                                    <!-- <option value="<?php echo e($mRow->bill_id); ?>"><?php echo e($datee."/".$mRow->bill_id); ?></option> -->
                                                </select>
                                            </div>
                                        </div>
                                        <a id="serchh" href="" class="btn btn-dark">Submit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
        <script>
            document.getElementById('invoice_date').addEventListener('change', function() {
              var bil_id = "monthDepositListSingleView/"+this.value;
              var depoLink = document.getElementById("serchh").href = bil_id;

            });

</script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/addmonthDepo.blade.php ENDPATH**/ ?>