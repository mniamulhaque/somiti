
  <?php $__env->startSection('body'); ?>
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Invoice</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Check Month Invoice</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Search Member Month Invoice</h4>
                                  <h4 class="card-title">
                                   <?php if($errors->has('memberNumber')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('memberNumber')); ?>

                                        </div>
                                    <?php elseif(Session::has('error')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e(Session::get('error')); ?>

                                        </div>
                                    <?php endif; ?>
                                 </h4>
                                <div class="basic-form">
                                    <form class="mt-5 mb-5 login-input" method="POST" action="<?php echo e(url('/checkMemberdeposit')); ?>">
                                     <?php echo csrf_field(); ?>
                                        <div class="form-row">
                                            <div class="form-group col-md-3"></div>
                                            <div class="form-group col-md-6">
                                                <input type="number" name="memberNumber" class="form-control" placeholder="Member Mobile or ID Nuumber" required>
                                            </div>
                                            <div class="form-group col-md-3"></div>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/searchMemberDeposit.blade.php ENDPATH**/ ?>