
  <?php $__env->startSection('body'); ?>
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="container mt-3">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="card-title"><?php echo e($shareBuying->sharePrice->Share_name); ?></h5>
                            </div>
                            <img class="img-fluid" src="<?php echo e(asset('backend_assets/images/'.$shareBuying->sharePrice->share_photo)); ?>" alt="">
                            <div class="card-body">
                                <p class="card-text"><?php echo e($shareBuying->sharePrice->about_share_explain); ?></p>
                            </div>
                            <div class="card-footer border-0 bg-transparent">
                                <div class="basic-list-group">
                                    <ul class="list-group">
                                        <?php
                                        $myInvest = (($shareBuying->shareInvest->sum('invest_amount')) / ($shareBuying->totalShare->sum('shareQuantity'))) * $shareBuying->shareQuantity
                                        ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total My Balance <span class="badge badge-primary badge-pill"><?php echo e(round(($shareBuying->MemberInvoicee->sum('payment')) - $myInvest, 2)); ?> ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Paid Quantity <span class="badge badge-primary badge-pill"><?php echo e(count($shareBuying->MemberInvoicee->where('payment','>',0))); ?></span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Paid Amount <span class="badge badge-primary badge-pill"><?php echo e($shareBuying->MemberInvoicee->sum('payment')); ?> ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Due Quantity <span class="badge badge-primary badge-pill"><?php echo e(count($shareBuying->MemberInvoicee)-count($shareBuying->MemberInvoicee->where('payment','>',0))); ?></span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Due Amount <span class="badge badge-primary badge-pill"><?php echo e($shareBuying->MemberInvoicee->sum('share_amount') - $shareBuying->MemberInvoicee->sum('payment')); ?> ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Share Price <span class="badge badge-primary badge-pill"><?php echo e($shareBuying->sharePrice->share_amount); ?> ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Share Quantity <span class="badge badge-primary badge-pill"><?php echo e($shareBuying->shareQuantity); ?></span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">Total Share Amount <span class="badge badge-primary badge-pill"><?php echo e($shareBuying->share_amount); ?> ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Invest <span class="badge badge-primary badge-pill"><?php echo e(round($myInvest, 2)); ?> ৳</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">My Profit <span class="badge badge-primary badge-pill"><?php echo e(round((($shareBuying->InvestProfit->sum('Profit_amount')) / $shareBuying->totalShare->sum('shareQuantity'))*$shareBuying->shareQuantity, 2)); ?> ৳</span>
                                        </li>
                                    </ul>
                                </div>
                                <hr>
                                <hr>
                                <h4 class="card-title mt-5">My Deposit List</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Month/Year</th>
                                                <th>Share Amount</th>
                                                <th>Paid/Unpaid</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $invoicMemberData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $date=date_create($row->invoice_date);
                                            $datee= date_format($date,"F/Y");
                                            ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($datee); ?></td>
                                                <td><?php echo e($row->share_amount); ?></td>
                                                <td>
                                                    <?php if($row->payment > 0): ?>
                                                    <i class="fa fa-circle-o text-success  mr-2"></i> Paid
                                                    <?php else: ?>
                                                    <i class="fa fa-circle-o text-warning  mr-2"></i> Unpaid
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.pages.userfolder.userlayout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/userfolder/userDetails.blade.php ENDPATH**/ ?>