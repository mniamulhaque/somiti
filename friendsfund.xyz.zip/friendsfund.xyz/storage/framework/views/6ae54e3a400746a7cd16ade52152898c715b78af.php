
  <?php $__env->startSection('body'); ?>
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Payment</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Create</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Create Payment</h4>
                                <h4 class="card-title">
                                   <?php if($errors->has('member_id')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('member_id')); ?>

                                        </div>
                                    <?php endif; ?>
                                 </h4>


                                <div class="basic-form">
                                     <form name="form1" class="forms-sample" action="<?php echo e(url('/pay_submit/')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <table class="table table-striped mb-3">
                                        <thead>
                                        <tr>
                                          <th>Qty</th>
                                          <th>Select</th>
                                          <th>Due Month</th>
                                          <th>Share Name</th>
                                          <th>Amount</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                          <input type="hidden" name="member_id" value="<?php echo e($id); ?>">
                                          <?php $__currentLoopData = $invoicMemberAllDue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $D_dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                          <td>1</td>
                                          <td><input type="checkbox" name="share_amountData[]" onchange="chkcontrol()" class="share_amountData" value="<?php echo e($D_dat->id); ?>" checked></td>
                                          <td><?php echo e($D_dat->invoice_date); ?></td>
                                          <td><?php echo e($D_dat->sharePrice->Share_name); ?></td>
                                          <td>
                                            <?php echo e($D_dat->share_amount); ?>

                                            <input type="hidden" name="share_amount[]" value="<?php echo e($D_dat->share_amount); ?>" class="share_amount">
                                          </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                          <td colspan="6"></td>
                                        </tr>
                                        </tbody>
                                      </table>
                                        <br><br>
                                        <div class="float-left">
                                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                        <a href="javascript: history.back()" class="btn btn-light">Cancel</a>
                                        </div>
                                        <div class="float-right mt-2" id="msg">Total : <?php echo e($invoicMemberAllDueSum); ?> tk</div>
                                      </form>
                              <!----form end----->
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
        <script type="text/javascript"> 
          function chkcontrol(j) {
          var sum=0;
          var elements = document.getElementsByClassName('share_amountData');
          var num = document.getElementsByClassName('share_amount');
          for(var i=0; i < elements.length; i++){

          if(elements[i].checked){
          sum = sum + parseInt(num[i].value);
          }
          document.getElementById("msg").innerHTML="Total : "+ sum+" tk";


          }
          }
        </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/createPayment.blade.php ENDPATH**/ ?>