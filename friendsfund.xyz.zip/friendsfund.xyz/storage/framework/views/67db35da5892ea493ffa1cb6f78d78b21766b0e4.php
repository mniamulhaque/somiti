
  <?php $__env->startSection('body'); ?>
        <!--**********************************
            Content body start
        ***********************************-->
    <div class="content-body">
    <div class="row page-titles mx-0">
        <div class="col p-md-0">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
            </ol>
        </div>
    </div>
    <!-- row -->

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                    <a href="<?php echo e(url('/createInvoic_month/'.$share_id)); ?>" class="btn btn-Primary mb-2">Create New Deposit Month</a>
                        <h4 class="card-title">Data Table</h4>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th>Si</th>
                                        <th>Id</th>
                                        <th>Deposit Created Month</th>
                                        <th>Total Member</th>
                                        <th>Due Member</th>
                                        <th>Paid Member</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $invoic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$InRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($InRow->bill_id); ?></td>
                                        <?php
                                        $date = date_create($InRow->invoice_date);
                                        $datee = date_format($date,"F - Y");
                                        ?>
                                        <td><?php echo e($datee); ?></td>
                                        <td><?php echo e(count($InRow->invoiceMember)); ?></td>
                                        <td><?php echo e(count($InRow->invoiceMemberDue)); ?></td>
                                        <td><?php echo e(count($InRow->invoiceMember) - count($InRow->invoiceMemberDue)); ?></td>
                                        <td><a href="<?php echo e(url('/monthDepositListSingleView/'.$InRow->bill_id)); ?>">View</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container -->
</div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/monthDepositList.blade.php ENDPATH**/ ?>