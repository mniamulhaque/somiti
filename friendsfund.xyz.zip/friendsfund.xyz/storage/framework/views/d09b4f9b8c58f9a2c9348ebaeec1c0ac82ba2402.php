
  <?php $__env->startSection('body'); ?>
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Member</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Add New Member</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">New Member Form</h4>
                                <h4 class="card-title">
                                   <?php if($errors->has('name')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('name')); ?>

                                        </div>
                                    <?php elseif($errors->has('father_name')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('father_name')); ?>

                                        </div>
                                    <?php elseif($errors->has('addr')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('addr')); ?>

                                        </div>
                                    <?php elseif($errors->has('nid')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('nid')); ?>

                                        </div>
                                    <?php elseif($errors->has('dob')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('dob')); ?>

                                        </div>
                                    <?php elseif($errors->has('mobile')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('mobile')); ?>

                                        </div>
                                    <?php elseif($errors->has('Alternative_number')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('Alternative_number')); ?>

                                        </div>
                                    <?php elseif($errors->has('profesion')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('profesion')); ?>

                                        </div>
                                    <?php elseif($errors->has('upazila')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('upazila')); ?>

                                        </div>
                                    <?php elseif($errors->has('district')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('district')); ?>

                                        </div>
                                    <?php elseif($errors->has('Divi')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('Divi')); ?>

                                        </div>
                                    <?php elseif($errors->has('password')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('password')); ?>

                                        </div>
                                    <?php elseif($errors->has('gender')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('gender')); ?>

                                        </div>
                                    <?php elseif($errors->has('nominiName')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('nominiName')); ?>

                                        </div>
                                    <?php elseif($errors->has('nominiSomorko')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('nominiSomorko')); ?>

                                        </div>
                                    <?php elseif($errors->has('NominiPhoto')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('NominiPhoto')); ?>

                                        </div>
                                    <?php elseif($errors->has('NominiNid_photo')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('NominiNid_photo')); ?>

                                        </div>
                                    <?php elseif(Session::has('message')): ?>
                                        <div class="alert alert-success" role="alert">
                                          <?php echo e(Session::get('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                 </h4>
                                <div class="basic-form">
                                    <form class="mt-5 mb-5 login-input" method="POST" action="<?php echo e(url('/addMember')); ?>" enctype="multipart/form-data">
                                     <?php echo csrf_field(); ?>
                                        <div class="form-row">
                                            <div class="form-group col-md-2">
                                                <label>Member Id</label>
                                                <input id="member_id" name="member_id" type="number" class="form-control"  value="<?php echo e($rollno); ?>" required readonly>
                                            </div>
                                            <div class="form-group col-md-5">
                                                <label>Name</label>
                                                <input id="name" name="name" type="text" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-5">
                                                <label>Father's Name</label>
                                                <input type="text" name="father_name" class="form-control" required>
                                                
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Address</label>
                                                <input type="text" name="addr" class="form-control" required>
                                                
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Nid No</label>
                                                <input type="number" name="nid" class="form-control" required>
                                                
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Gender</label>
                                                <select id="gender" name="gender" class="form-control">
                                                    <option selected="selected">Choose Gender...</option>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>DOB</label>
                                                <input type="date" name="dob" class="form-control" required>
                                                
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Mobile No</label>
                                                <input type="number" name="mobile" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Alternative Number</label>
                                                <input type="number" name="Alternative_number" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Profession</label>
                                                <input type="text" name="profesion" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Member Photo</label>
                                                 <input type="file" class="form-control-file" name="photo" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Nid Photo(Back and frond)</label>
                                                <input type="file" class="form-control-file" name="nid_photo" required>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label>Upazila</label>
                                                <input type="text" name="upazila" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>District</label>
                                                <input type="text" name="district" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label>Division</label>
                                                <input type="text" name="Divi" class="form-control" required>
                                            </div>
                                        </div>
                                        <hr>
                                        <h4>Nomoni Information...</h4>
                                        <hr>
                                         <div class="form-row">
                                            <div class="form-group col-md-3">
                                                <label>Nomini Name</label>
                                                <input type="text" name="nominiName" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label>Nomini Somorko</label>
                                                <input type="text" name="nominiSomorko" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label>Nomini Photo</label>
                                                 <input type="file" class="form-control-file" name="NominiPhoto" required>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label>Nomini Nid Photo(Back and frond)</label>
                                                <input type="file" class="form-control-file" name="NominiNid_photo" required>
                                            </div>
                                        </div>
                                        <hr>
                                        <h4>Login Information...</h4>
                                        <hr>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <input id="email" type="text" class="form-control"  placeholder="Email" name="email"/>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <input id="password" class="form-control"   type="password" placeholder="password" name="password" required/>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Add Member</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/addMember.blade.php ENDPATH**/ ?>