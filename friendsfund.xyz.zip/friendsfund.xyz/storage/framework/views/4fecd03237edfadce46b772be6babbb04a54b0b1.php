
  <?php $__env->startSection('body'); ?>
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Deposit</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Add Share Name</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                  <h4 class="card-title">
                                    <?php if($errors->has('share_id')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('share_id')); ?>

                                        </div>
                                    <?php elseif(Session::has('message')): ?>
                                        <div class="alert alert-success" role="alert">
                                          <?php echo e(Session::get('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                 </h4>
                                <div class="basic-form">
                                    
                                        <div class="form-row">
                                            <div class="form-group col-md-3"></div>
                                            <div class="form-group col-md-6">
                                                <label>Select Share</label>
                                                <select onchange="myFunc" id="share_id" name="share_id" class="form-control">
                                                    <option value="">Choose Share...</option>
                                                    <?php $__currentLoopData = $Share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <option value="<?php echo e($mRow->id); ?>"><?php echo e($mRow->Share_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-3"></div>
                                        </div>
                                        <a id="serchh" href="" class="btn btn-dark">Submit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
        <script>
            document.getElementById('share_id').addEventListener('change', function() {
              var Share_id = "monthDepositList/"+this.value;
              var depoLink = document.getElementById("serchh").href = Share_id;

            });

</script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/createMonthDepo.blade.php ENDPATH**/ ?>