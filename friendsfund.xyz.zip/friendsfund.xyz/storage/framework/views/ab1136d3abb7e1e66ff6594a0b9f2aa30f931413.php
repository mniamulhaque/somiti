
  <?php $__env->startSection('body'); ?>
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Member Details</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                            <tr>
                                                <th>Member Id</th>
                                                <td><?php echo e($userData->member_id); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Name</th>
                                                <td><?php echo e($userData->name); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Father Name</th>
                                                <td><?php echo e($userData->father_name); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Addr</th>
                                                <td><?php echo e($userData->addr.",".$userData->upazila.",".$userData->district.",".$userData->Divi); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Mobile</th>
                                                <td><?php echo e($userData->mobile); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Alternative Number</th>
                                                <td><?php echo e($userData->Alternative_number); ?></td>
                                            </tr>
                                            <?php
                                            $shareD = App\createShare::where('id',$userData->share_id)->first();
                                            ?>
                                            <tr>
                                                <td style="background:tomato;color: #fff;" colspan="2">
                                                <?php echo e($shareD->Share_name); ?>

                                            </td>
                                            </tr>
                                            <tr>
                                                <th>Share Name</th>
                                                <td><?php echo e($shareD->Share_name); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Share Quntity</th>
                                                <td><?php echo e($userData->shareQuantity); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Share Price</th>
                                                 <td><?php echo e($shareD->share_amount); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Total Share Amount</th>
                                                 <td><?php echo e($shareD->share_amount." * ".$userData->shareQuantity." = ".$userData->share_amount); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Share Buying Date</th>
                                                <td><?php echo e($userData->buying_date); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Deposit Due</th>
                                                <td><?php echo e($memberInvoiceData->sum('share_amount') - $memberInvoiceData->sum('payment')); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Total Deposit Amount</th>
                                                <td><?php echo e($memberInvoiceData->sum('payment')); ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><hr style="border:2px solid tomato;"/>
                                            </td>
                                            <tr>
                                                <th>Gender</th>
                                                <td><?php echo e($userData->gender); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Date of Birth</th>
                                                <td><?php echo e($userData->dob); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Nid Number</th>
                                                <td><?php echo e($userData->nid); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Gender</th>
                                                <td><?php echo e($userData->gender); ?></td>
                                            </tr>
                                            <tr>
                                                <th colspan="2">Information Picture</th>
                                            </tr>
                                            <tr>
                                                <td><img style="height: 100px; width: 100px;" src="<?php echo e(asset('backend_assets/images/member/'.$userData->photo)); ?>" alt=""></td>
                                                <td><img style="height: 100px; width: 100px;" src="<?php echo e(asset('backend_assets/images/member/'.$userData->nid_photo)); ?>" alt=""></td>
                                            </tr>
                                            <tr>
                                                <th colspan="2">Nominee Information</th>
                                            </tr>
                                            <tr>
                                                <th>Nominee Name</th>
                                                <td><?php echo e($userData->nominiName); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Nominee Relation</th>
                                                <td><?php echo e($userData->nominiSomorko); ?></td>
                                            </tr>
                                            <tr>
                                                <th colspan="2">Nominee Information Picture</th>
                                            </tr>
                                            <tr>
                                                <td><img style="height: 100px; width: 100px;" src="<?php echo e(asset('backend_assets/images/member/'.$userData->NominiPhoto)); ?>" alt=""></td>
                                                <td><img style="height: 100px; width: 100px;" src="<?php echo e(asset('backend_assets/images/member/'.$userData->NominiNid_photo)); ?>" alt=""></td>
                                            </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/buyermemberSingleView.blade.php ENDPATH**/ ?>