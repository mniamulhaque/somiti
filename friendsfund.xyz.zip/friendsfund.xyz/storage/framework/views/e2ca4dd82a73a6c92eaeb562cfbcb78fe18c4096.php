
  <?php $__env->startSection('body'); ?>
        <!--**********************************
            Content body start
        ***********************************-->
                <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="navbarcreate">
                                    <ul class="nav_ul">
                                      <li><a class="activee" href="#home">Home</a></li>
                                      <li><a href="#news">News</a></li>
                                      <li><a href="#contact">Contact</a></li>
                                      <li style="float:right"><a href="#about">About</a></li>
                                    </ul>
                                </div>
                                <h4 class="card-title"></h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Si</th>
                                                <th>Name</th>
                                                <th>Father <br>Name</th>
                                                <th>Mobile</th>
                                                <th>Share <br>Quntity</th>
                                                <th>Due</th>
                                                <th>Paid</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$mRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <?php
                                             $memberInvoiceData =  App\memberInvoice::where('member_id',$mRow->member_id)->where('share_id',$mRow->share_id)->get()
                                             ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($mRow->name); ?></td>
                                                <td><?php echo e($mRow->father_name); ?></td>
                                                <td><?php echo e($mRow->mobile); ?></td>
                                                <td><?php echo e($mRow->shareQuantity); ?></td>
                                                <td><?php echo e($memberInvoiceData->sum('share_amount') - $memberInvoiceData->sum('payment')); ?></td>
                                                <td><?php echo e($memberInvoiceData->sum('payment')); ?></td>
                                                <td><a href="<?php echo e(url('/byermemberview/'.$mRow->id)); ?>">View</a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/shareBuyerList.blade.php ENDPATH**/ ?>