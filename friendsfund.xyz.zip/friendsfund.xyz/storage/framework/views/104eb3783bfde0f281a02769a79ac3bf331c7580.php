
  <?php $__env->startSection('body'); ?>
     <!--**********************************
            Content body start
      ***********************************-->
      
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Share</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Buy Share</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Buy Share Form</h4>
                                <h4 class="card-title">
                                   <?php if($errors->has('member_id')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('member_id')); ?>

                                        </div>
                                    <?php elseif($errors->has('share_id')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('share_id')); ?>

                                        </div>
                                <?php elseif($errors->has('shareQuantity')): ?>
                                      <div class="alert alert-danger" role="alert">
                                          <?php echo e($errors->first('shareQuantity')); ?>

                                        </div>
                                <?php elseif($errors->has('buying_date')): ?>
                                      <div class="alert alert-danger" role="alert">
                                    <?php echo e($errors->first('buying_date')); ?>

                                        </div>
                                    <?php elseif(Session::has('error')): ?>
                                        <div class="alert alert-danger" role="alert">
                                          <?php echo e(Session::get('error')); ?>

                                        </div>
                                    <?php elseif(Session::has('message')): ?>
                                        <div class="alert alert-success" role="alert">
                                          <?php echo e(Session::get('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                 </h4>
                                <div class="basic-form">
                                    <form class="forms-sample" action="<?php echo e(url('/buyshare')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Member Name</label>
                                                <select id="member_id" name="member_id" class="form-control">
                                                    <option value="">Choose Name...</option>
                                                    <?php $__currentLoopData = $memberData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($mRow->id); ?>"><?php echo e($mRow->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Share Name</label>
                                                <select id="share_id" name="share_id" class="form-control">
                                                    <option value="">Choose Name...</option>
                                                    <?php $__currentLoopData = $ShareData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sRow->id); ?>"><?php echo e($sRow->Share_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Share Quantity</label>
                                                <input type="number" name="shareQuantity" class="form-control" placeholder="Type Share Quantity">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <div class="form-group">
                                                    <label>Buying Date</label>
                                                    <input type="date" name="buying_date" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Buy</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
  <!--**********************************
            Content body end
        ***********************************-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ddksldzr/friendsfund.xyz/resources/views/backend/pages/buyShare.blade.php ENDPATH**/ ?>