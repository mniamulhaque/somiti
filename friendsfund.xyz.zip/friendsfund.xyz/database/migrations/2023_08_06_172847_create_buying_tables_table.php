<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBuyingTablesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('buying_tables', function (Blueprint $table) {
            $table->id();
            $table->integer('member_id');
            $table->integer('share_id');
            $table->integer('share_amount');
            $table->integer('shareQuantity');
            $table->string('buying_date');
            $table->string('added_by');
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('buying_tables');
    }
}
