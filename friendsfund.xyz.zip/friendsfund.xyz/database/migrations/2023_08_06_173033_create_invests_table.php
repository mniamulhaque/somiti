<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInvestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invests', function (Blueprint $table) {
            $table->id();
            $table->string('share_id');
            $table->string('invest_name');
            $table->string('lonaner_name');
            $table->string('invest_amount');
            $table->string('lonan_expair_date');
            $table->string('profit_system');
            $table->string('Profit_amount');
            $table->string('about_invest_explain');
            $table->string('added_by');
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('invests');
    }
}
