<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMemberAddsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('member_adds', function (Blueprint $table) {
            $table->id();
            $table->integer('member_id');
            $table->string('name');
            $table->string('dob');
            $table->string('addr');
            $table->string('district');
            $table->string('upazila');
            $table->string('Divi');
            $table->bigInteger('nid');
            $table->string('father_name');
            $table->integer('mobile');
            $table->integer('Alternative_number');
            $table->string('profesion');
            $table->string('email');
            $table->string('password');
            $table->string('gender');
            $table->string('memberType');
            $table->integer('shareId');
            $table->string('photo');
            $table->string('nid_photo');
            $table->string('nominiName');
            $table->string('nominiSomorko');
            $table->string('NominiPhoto');
            $table->string('NominiNid_photo');
            $table->string('added_by');
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('member_adds');
    }
}
