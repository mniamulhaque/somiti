<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMemberInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('member_invoices', function (Blueprint $table) {
            $table->id();
            $table->integer('invoice_date_id');
            $table->string('invoice_date');
            $table->integer('member_id');
            $table->integer('share_id');
            $table->integer('share_amount');
            $table->integer('payment');
            $table->string('pay_date');
            $table->string('added_by_month');
            $table->string('added_by');
            $table->integer('active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('member_invoices');
    }
}
